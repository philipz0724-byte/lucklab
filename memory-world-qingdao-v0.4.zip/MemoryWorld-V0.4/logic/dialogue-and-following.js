// Native GDevelop JavaScript event. State lives in declared global variables.
// This event supplies dialogue and breadcrumb following; native events own scene changes.
const scene = runtimeScene;
const globals = scene.getGame().getVariables();
const get = n => globals.get(n).getAsNumber();
const set = (n,v) => globals.get(n).setNumber(v);
const obj = n => scene.getObjects(n)[0];
const text = (n,s) => {const o=obj(n);if(o && o.getString()!==s)o.setString(s);};
const wrap = (s,max=39) => s.split('\n').map(line=>{
  let out='',width=0;for(const ch of line){const w=ch.charCodeAt(0)>255?1:0.54;if(width+w>max){out+='\n';width=0;}out+=ch;width+=w;}return out;
}).join('\n');
const player=obj('Player');
const sceneId = {Mall:1,BBQ:2,Sea:3,Cafe:4}[scene.getName()];
const local=scene.getVariables();
const down=k=>['1','2','3'].includes(k)
  ? gdjs.evtTools.input.isKeyPressed(scene,'Num'+k)||gdjs.evtTools.input.isKeyPressed(scene,'Numpad'+k)
  : gdjs.evtTools.input.isKeyPressed(scene,k);
if(!scene._mw){
  scene._mw={keys:{},dialog:null,page:0,trail:[],last:[player.getX(),player.getY()],ticks:0,selected:0,resetUntil:0};
  const m=scene._mw;
  // Prime all input keys on scene entry so held keys cannot activate another portal.
  for(const k of ['e','Space','Return','1','2','3','j','r','Escape'])m.keys[k]=down(k);
  const backwards=get('ReturnFrom')>sceneId;
  if(backwards)player.setPosition(814,362);
  set('ReturnFrom',0);
  for(const o of scene.getObjects('Solid'))o.hide();
  for(const n of ['Strong','Guard']){
    const o=obj(n);if(o && (sceneId>1 || get(n==='Strong'?'MetStrong':'GuardJoined')))o.setPosition(player.getX()-60*(n==='Strong'?1:2),player.getY());
  }
  for(let i=0;i<60;i++)m.trail.push({x:player.getX(),y:player.getY(),direction:0});
}
const m=scene._mw;
const keys={};for(const k of ['e','Space','Return','1','2','3','j','r','Escape']){keys[k]=down(k)&&!m.keys[k];m.keys[k]=down(k);}
const pressed = keys.e||keys.Space||keys.Return;
const page=(who,s)=>({who,text:s});
const say=(pages,done=null,choices=null)=>{m.dialog={pages,done,choices};m.page=0;m.selected=0;};
const close=()=>{const done=m.dialog&&m.dialog.done;m.dialog=null;m.page=0;if(done)done();};
const go=id=>{set('ReturnFrom',sceneId);set('NextScene',id);};
const mark=(flag,value=1)=>set(flag,Math.max(get(flag),value));
const memories=()=>['MetStrong','GuardJoined','Ate','SeaWalk','Photo','Stones','Finished'].filter(n=>get(n)).length;
const pick=i=>{const choices=m.dialog&&m.dialog.choices;if(!choices||m.page!==m.dialog.pages.length-1||!choices[i])return;const fn=choices[i].run;m.dialog=null;if(fn)fn();};
if(keys.r){
  say([page('重新走一遍？','从商场重新开始，会清空这次预览里的进度。')],null,[
    {label:'继续今晚',run:()=>{}},
    {label:'重新开始',run:()=>{for(const n of ['MetStrong','GuardJoined','Ordered','Ate','Roast','SeaWalk','Photo','Stones','Role','MatchStep','Synergy','Finished','Stage','NextScene','ReturnFrom'])set(n,0);set('NextScene',1);}}
  ]);
} else if(keys.j&&!m.dialog){
  const done=n=>get(n)?'已留下':'还没发生';
  say([
    page('今晚的小记 · 1 / 3',`商场碰面：${done('MetStrong')}。\n等朋友下班：${done('GuardJoined')}。`),
    page('今晚的小记 · 2 / 3',`肥瘦相间的羊肉串：${done('Ate')}。\n团岛 / 栈桥附近的海风：${done('SeaWalk')}。`),
    page('今晚的小记 · 3 / 3',`海边合照：${done('Photo')}；打水漂：${done('Stones')}。\n三人开黑：${done('Finished')}。可选的小事，想做就做。`)
  ]);
} else if(m.dialog){
  if(m.dialog.choices&&m.page===m.dialog.pages.length-1){
    if(keys['1'])pick(0);else if(keys['2'])pick(1);else if(keys['3'])pick(2);
  }else if(pressed){if(m.page<m.dialog.pages.length-1)m.page++;else close();}
}else if(pressed){
  const target=m.nearest;
  if(target){
    if(target.id==='strong'){
      if(!get('MetStrong'))say([
        page('壮实朋友','你可算来了。长这么高，隔两条街就看见你了。'),
        page('你','那你还不赶紧过来迎接？'),
        page('壮实朋友','我是你爹，还迎接你？走，去接那个上班的。'),
        page('你','行行行，今天学生代表陪他下班。')
      ],()=>{mark('MetStrong');mark('Stage',1);});
      else say([page('壮实朋友',get('GuardJoined')?'人齐了，去吃串。你这大个子别把路灯挡了。':'他就在商场门口，走近点叫他。')]);
    }else if(target.id==='guard'){
      if(!get('MetStrong'))say([page('胖胖朋友','你先去跟那位碰个头，我这边马上交班。')]);
      else if(!get('GuardJoined'))say([
        page('胖胖朋友','等我一下，交班就走。你俩别堵在这儿，跟门神似的。'),
        page('壮实朋友','我们来视察工作。你这保安当得挺有气势啊。'),
        page('胖胖朋友','我是你爹。视察完请我吃串。')
      ],null,[
        {label:'走，羊肉串安排',run:()=>say([page('你','安排！肥瘦相间的，谁都别跟我抢。'),page('胖胖朋友','下班！走走走，站了一天，正好活动活动。')],()=>{mark('GuardJoined');mark('Stage',2);})},
        {label:'先让你嘚瑟一会',run:()=>say([page('你','让你嘚瑟一会儿。下了班还不是得跟我们混。'),page('胖胖朋友','混就混，先吃饭。我快饿成瘦子了。')],()=>{mark('GuardJoined');mark('Stage',2);})}
      ]);
      else say([page('胖胖朋友','交完班了，今晚听肚子的。烧烤摊，出发！')]);
    }else if(target.id==='notice')say([page('你','商场还亮着灯，门口有人提着袋子来来往往。'),page('壮实朋友','别看了，咱们今天的购物清单只有羊肉串。')]);
    else if(target.id==='order'){
      if(get('Ordered'))say([page('摊主','你们的串好了，坐旁边那桌趁热吃。')]);
      else say([page('摊主','三个小伙儿，吃点什么？'),page('你','羊肉串！要肥瘦相间的，烤得滋滋冒油那种。')],null,[
        {label:'先来三十串',run:()=>say([page('摊主','好嘞，先上三十，不够再加。'),page('壮实朋友','这才像样。刚才谁说随便吃两口来着？')],()=>mark('Ordered'))},
        {label:'先来二十串，不够再加',run:()=>say([page('胖胖朋友','二十？你那两米的胃就吃这点？'),page('你','先烤着，不够再加，急什么。')],()=>mark('Ordered'))}
      ]);
    }else if(target.id==='table'){
      if(!get('Ordered'))say([page('壮实朋友','先到烤炉前点串啊，总不能干坐着闻味儿。')]);
      else if(!get('Ate'))say([
        page('你','肥的焦香，瘦的还嫩。撒上孜然，热气直往脸上扑。'),
        page('胖胖朋友','就这个味儿！这可比我今天的工作餐强多了。'),
        page('壮实朋友','你先把嘴里的咽了再说，没人跟你抢。')
      ],null,[
        {label:'我是你爹，给我留两串',run:()=>say([page('你','我是你爹！给我留两串。'),page('胖胖朋友','行，那这单爹结。'),page('壮实朋友','哈哈哈哈，认爹这事儿也能反噬啊。'),page('你','吃饱了，去海边溜达。')],()=>{mark('Ate');mark('Roast',1);mark('Stage',3);})},
        {label:'谁最后吃完谁收拾',run:()=>say([page('你','谁最后吃完谁收拾。'),page('壮实朋友','你先把手里那四串放下再制定规则。'),page('胖胖朋友','全桌最忙的就是你的嘴。'),page('你','哈哈哈，吃饱了去海边。')],()=>{mark('Ate');mark('Roast',2);mark('Stage',3);})}
      ]);
      else say([page('胖胖朋友','再坐会儿也行。你俩一张嘴，这桌就安静不了。'),page('你','串吃完了，孜然味还在手上。')]);
    }else if(target.id==='sea'){
      if(!get('SeaWalk'))say([
        page('你','从团岛这边往栈桥附近走，海风一下就把烧烤摊的热气吹散了。'),
        page('壮实朋友','你别站我前面，风都让你挡了。'),
        page('你','挡风还不好？这身高总得派点用场。'),
        page('胖胖朋友','那你给我挡着，我刚吃饱，可不能吹瘦了。'),
        page('你','三个人沿着栏杆慢慢走。想到什么说什么，也没谁催着往哪儿赶。')
      ],()=>{mark('SeaWalk');mark('Stage',4);});
      else say([page('壮实朋友','再吹会儿风？'),page('胖胖朋友','行啊，网吧又不会长腿跑了。')]);
    }else if(target.id==='photo'){
      if(get('Photo'))say([page('你','照片里一个太高、一个太壮、一个笑得眼睛都快没了。刚好三个人。')]);
      else say([page('你','来来来，凑近点，拍一张。'),page('胖胖朋友','你把手机举那么高，拍监控呢？')],null,[
        {label:'蹲一点，三人挤进镜头',run:()=>say([page('壮实朋友','对，这才齐。别憋着，都笑。'),page('你','咔嚓。海是黑的，人是乐的。')],()=>mark('Photo'))},
        {label:'算了，接着溜达',run:()=>say([page('你','行，先不拍。走哪儿算哪儿。')])}
      ]);
    }else if(target.id==='stones'){
      if(get('Stones'))say([page('胖胖朋友','刚才那一下挺响。你的石头可能比较想直接下班。')]);
      else say([page('壮实朋友','看我这个，能漂好几下。'),page('你','我试试。捡了块小石头，侧着身子往水面一送。')],null,[
        {label:'认真甩出去',run:()=>say([page('你','一、二、三。还真跳了几下。'),page('壮实朋友','可以啊，待会儿游戏也有这个准头就行。')],()=>mark('Stones'))},
        {label:'使劲来一下',run:()=>say([page('你','咚！'),page('胖胖朋友','哈哈哈哈，你这是给海打了个标点。')],()=>mark('Stones'))}
      ]);
    }else if(target.id==='pc'){
      if(get('Finished'))say([page('壮实朋友','还来一把？'),page('胖胖朋友','来呗。反正人齐了。'),page('你','这就是今晚。吃了串，吹了风，三个人挤在一排电脑前。')]);
      else if(get('MatchStep')===0){
        say([page('胖胖朋友','三台挨着的，正好。今天打 LOL，谁跟谁走？'),page('壮实朋友','先说好，别一打起来就只会喊我是你爹。')],null,[
          {label:'我打上路',run:()=>say([page('你','我去上路，你们来就给你们留人头。'),page('壮实朋友','行，你先别把自己留在那儿。')],()=>{set('Role',1);set('MatchStep',1);})},
          {label:'我打野来帮你们',run:()=>say([page('你','我打野，等我来。'),page('胖胖朋友','这句话我记住了啊，别逛一整局。')],()=>{set('Role',2);set('MatchStep',1);})},
          {label:'我去下路',run:()=>say([page('你','我去下路，咱俩一起。'),page('胖胖朋友','走，让他们见识一下咱俩的配合。')],()=>{set('Role',3);set('MatchStep',1);})}
        ]);
      }else if(get('MatchStep')===1){
        say([page('开黑 · 第一回合','小地图上队友打了信号。你们的声音盖过了旁边的键盘声。'),page('壮实朋友','来来来，有机会！')],null,[
          {label:'看一眼小地图，一起上',run:()=>say([page('你','等我到，一起。'),page('胖胖朋友','漂亮！早这么配合不就完了。')],()=>{set('Synergy',get('Synergy')+1);set('MatchStep',2);})},
          {label:'先喊一句：我是你爹',run:()=>say([page('你','我是你爹！人来了人来了！'),page('壮实朋友','哈哈哈，先走位！你的嘴比技能快。')],()=>set('MatchStep',2))}
        ]);
      }else if(get('MatchStep')===2){
        say([page('开黑 · 第二回合','一波打完，三个人都往椅子前沿凑了凑。'),page('胖胖朋友','这波推塔还是再追？')],null,[
          {label:'一起推塔',run:()=>say([page('你','塔塔塔，先把塔推了。'),page('壮实朋友','可以，今天有脑子了啊。')],()=>{set('Synergy',get('Synergy')+1);set('MatchStep',3);})},
          {label:'追两步，笑着收手',run:()=>say([page('你','追一下……算了算了，回来。'),page('胖胖朋友','我都替你准备好笑话了，居然还知道回来。')],()=>set('MatchStep',3))}
        ]);
      }else{
        const result=get('Synergy')===2?'这把配合得顺，推掉基地的时候，三个人同时喊了出来。':get('Synergy')===1?'这一把打得有来有回。最后一波结束，旁边两个人还在复盘刚才谁最能喊。':'这一把笑得比打得还热闹。输赢刚跳出来，就已经有人在说下一把怎么打。';
        say([
          page('一局结束',result),
          page('壮实朋友','再来一把？'),page('胖胖朋友','来啊。刚才那波我还没发挥呢。'),
          page('你',get('Roast')===1?'行，爹再带你们一把。':'来来来，这把谁嘴最硬谁先请饮料。'),
          page('青岛的那些夜晚','一顿肥瘦相间的羊肉串，一路海风，一排亮着的电脑。人都在，想做什么就去做。'),
          page('今晚，就这样挺好','没有非得完成的大事。三个人笑着，下一把已经排上了。')
        ],()=>{mark('Finished');mark('Stage',5);});
      }
    }else if(target.id==='counter')say([page('网管','靠里那三台空着，坐一排吧。'),page('胖胖朋友','好嘞，再拿三瓶饮料。')]);
    else if(target.id==='forward'){
      if(sceneId===1){if(get('GuardJoined'))go(2);else say([page('你','人还没齐。先跟壮实的朋友碰头，再接胖胖的朋友下班。')]);}
      if(sceneId===2){if(get('Ate'))go(3);else say([page('胖胖朋友','吃完再去海边。先点串，再到左边那桌坐坐。')]);}
      if(sceneId===3){if(get('SeaWalk'))go(4);else say([page('你','海边都到了，先去中间栏杆那儿吹吹风。')]);}
    }else if(target.id==='back')go(sceneId-1);
  }
}
// Update movement lock before native WASD events run.
const locked=!!m.dialog||get('NextScene')!==0;
player.activateBehavior('TopDownMovement',!locked);
local.get('DialogOpen').setNumber(locked?1:0);
const [lx,ly]=m.last;const dx=player.getX()-lx,dy=player.getY()-ly;
let direction=m.direction||0;
if(Math.abs(dx)+Math.abs(dy)>0.1){direction=Math.abs(dx)>Math.abs(dy)?(dx>0?3:2):(dy>0?0:1);player.setAnimation(direction);player.playAnimation();}else player.pauseAnimation();
m.direction=direction;m.last=[player.getX(),player.getY()];
const head=m.trail[m.trail.length-1];
if(Math.hypot(player.getX()-head.x,player.getY()-head.y)>=3){m.trail.push({x:player.getX(),y:player.getY(),direction});if(m.trail.length>350)m.trail.shift();}
const trailAt=distance=>{let rem=distance;for(let i=m.trail.length-1;i>0;i--){const a=m.trail[i],b=m.trail[i-1];const len=Math.hypot(a.x-b.x,a.y-b.y);if(len>=rem&&len>0){const f=rem/len;return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,direction:a.direction};}rem-=len;}return m.trail[0];};
for(const [n,flag,offset] of [['Strong','MetStrong',55],['Guard','GuardJoined',110]]){
 const o=obj(n);if(!o)continue;
 if(get(flag)){
  const p=trailAt(offset);const move=Math.hypot(o.getX()-p.x,o.getY()-p.y);o.setPosition(p.x,p.y);o.setAnimation(p.direction);if(move>.1)o.playAnimation();else o.pauseAnimation();
 }
 o.setZOrder(Math.round(o.getY()+66));
 const label=obj('Label'+n);if(label){label.setPosition(o.getX()-6,o.getY()-15);label.setZOrder(500);}
 if(label)text('Label'+n,get(flag)?(n==='Strong'?'壮实':'胖胖'):(n==='Strong'?'壮实朋友':'胖胖朋友'));
}
player.setZOrder(Math.round(player.getY()+66));
// Only story destinations are targeted after companions join; followers never steal the action key.
let targets=[];
const target=(id,label,x,y,r=88)=>targets.push({id,label,x,y,r});
if(sceneId===1){
 if(!get('MetStrong')){const o=obj('Strong');target('strong','和壮实的朋友碰头',o.getX()+28,o.getY()+55);}
 if(!get('GuardJoined')){const o=obj('Guard');target('guard','等胖胖的朋友下班',o.getX()+28,o.getY()+55);}
 target('notice','看看商场门口',172,295,65);target('forward','去路边烧烤',900,437,80);
}else if(sceneId===2){target('order','点羊肉串',426,326,90);target('table','坐下吃串、聊两句',145,372,82);target('forward','去海边',905,438);target('back','回商场',45,438,60);
}else if(sceneId===3){target('sea','吹吹海风',470,340,82);target('photo','三人合个照（可选）',166,342,70);target('stones','打个水漂（可选）',593,389,65);target('forward','去网吧开黑',905,438);target('back','回烧烤摊',45,438,60);
}else{target('pc',get('Finished')?'再聊两句':get('MatchStep')?'继续这局 LOL':'坐下，三人开黑',357,427,95);target('counter','跟网管打招呼',805,421,80);target('back','回海边走走',48,438,60);}
const px=player.getX()+28,py=player.getY()+60;
let nearest=null,dist=Infinity;for(const t of targets){const v=Math.hypot(px-t.x,py-t.y);if(v<t.r&&v<dist){nearest=t;dist=v;}}
m.nearest=nearest;
const tasks=sceneId===1?(!get('MetStrong')?'先和左边壮实的朋友碰面':!get('GuardJoined')?'走到商场门前，等胖胖的朋友下班':'人齐了！往右走，去路边烧烤'):
 sceneId===2?(!get('Ordered')?'走近烤炉，点肥瘦相间的羊肉串':!get('Ate')?'到左边小圆桌，吃串、互相损两句':'吃饱了，右边出发去海边'):
 sceneId===3?(!get('SeaWalk')?'走到中间栏杆旁，吹吹海风':'可以合照、打水漂；玩够了往右去网吧'):
 get('Finished')?'今晚已完成。可以回海边、按 J 看小记，或按 R 重玩':get('MatchStep')?'走近中间那排电脑，按 E 继续这局':'到中间那排电脑旁，和朋友一起打 LOL';
text('Task',tasks);text('Counter',`回忆 ${memories()} / 7`);
text('Prompt',!locked&&nearest?'[ E ] '+nearest.label:'');
if(m.dialog){
 const p=m.dialog.pages[m.page];text('Speaker',p.who);text('Dialogue',wrap(p.text));
 const final=m.page===m.dialog.pages.length-1;
 text('Choices',final&&m.dialog.choices?m.dialog.choices.map((c,i)=>`${i+1}  ${c.label}`).join('    '):'E / 空格 / Enter  继续');
}else{
 text('Speaker',get('Finished')?'今晚，就这样挺好':'今夜无事，和朋友一起。');
 text('Dialogue',get('Finished')?'青岛的那些夜晚 · V0.4\n吃串，吹风，开黑。下一把，人还是齐的。':wrap(tasks+'。\n走近人物或地点，看到提示后按 E 互动。'));
 text('Choices','WASD / 方向键 走动    E 互动    1 / 2 / 3 选择    J 小记    R 重玩');
}
