# V0.4 验证记录

验证日期：2026-10-22。引擎：本机已安装的 GDevelop 5.6.284。

## 已完成

- JSON 可解析；4 个场景、38 个本地图片资源、107 个初始实例、56 条事件条目完整。
- 所有 Sprite 帧引用的图片均已登记，所有资源文件存在，实例对象名有效；工程不依赖远程素材。
- 使用安装版中的 **libGD.js + libGD.wasm 原生项目解析器和正式导出器**载入 `game.json`，成功编译全部四幕。WholeProjectDiagnosticReport.hasAnyIssue() 为 false。
- 核对导出的实际事件代码：跨场景任务访问 game 全局变量；DialogOpen 访问 scene 变量；Scene 动作切换到四个真实场景，不是模拟网页。
- 在独立 Chromium 浏览器运行上述官方导出结果，从全新进度开始，仅通过真实键盘输入走通：商场碰面 → 接下班 → 点串 → 吃串 → 海边散步 → 合照 → 打水漂 → 网吧选择角色 → 两回合 → 结尾。
- 实测对话锁定移动、返回旧地图保留所有标记、取消重玩不清空、确认重玩全部清零，以及地图边界碰撞。
- 将测试状态明确放到各分支入口，补充验证全部 3 个主线出口锁定；另一种接人/点串/互损分支；拒绝合照后重新拍照；另一种打水漂分支。
- 用相同真实 GDevelop 运行时，验证全部 **3 × 2 × 2 = 12 种** LOL 角色与回合选择组合均正常结尾，分数不重复累加。
- 本轮运行没有 JavaScript 异常，没有游戏资源加载失败。浏览器 favicon 请求不属于游戏资源。
- 已目视检查商场、烧烤、海边、网吧结尾画面，中文显示和对话布局正常；最终缩短入队后的姓名标签，避免紧挨时文字重叠。

详细自动化结果见 `playtest-report.json`。主线完整试玩与分支入口测试在该文件中分开记录，未把预置分支状态当作从头通关。

## 验证边界

- 编辑器的系统文件选择窗口未能由自动化完成打开，因此这里不宣称已在桌面编辑器界面手点「预览」成功。**项目已通过该安装版本的同一原生项目解析、完整编译和实际运行验证**。用户导入步骤见 README。
- 测试平台为 macOS 上的 Chromium 和 GDevelop 5.6.284；没有验证所有旧版 GDevelop、手机触屏或手柄。本版为桌面键盘玩法。
- 无音乐/配音、无跨次启动存档。朋友为轨迹跟随，场景入口重新集合；LOL 为文字选择互动。

## 状态设计

| 全局变量 | 用途 |
| --- | --- |
| MetStrong / GuardJoined | 两位朋友入队，控制商场出口 |
| Ordered / Ate / Roast | 点串、吃完、互损选择；控制海边解锁及结尾台词 |
| SeaWalk / Photo / Stones | 主线散步与两个独立可选回忆 |
| Role / MatchStep / Synergy / Finished | LOL 角色、单调推进的回合、配合结果和结尾完成标记 |
| Stage | 只前进的主线里程碑，重玩时清零 |
| NextScene / ReturnFrom | 一次性切场景请求及回程出生点 |

对话页码和按键边沿保存在每个场景的临时控制器中。按住互动键不会跨场景连触发；完成回调只在对话结束时执行；每回合推进 MatchStep 后无法再次刷本回合分数。

## 来源

参考工程：`philipz0724-byte/lucklab` 的 `memory-world-gdevelop-cross-scene-v3` 分支，`memory-world-cross-scene-v3.zip`，提交 `20f0bc5e60eaeb7ede267f9d7da20f03a817b4d1`。

保留参考工程已经使用的标准事件、资源、对象和场景结构。新的对话与跟随使用 GDevelop 官方支持的原生 JavaScript 事件：[GDevelop JavaScript Code events](https://wiki.gdevelop.io/gdevelop5/events/js-code/)。
