Memory World - GDevelop V0.3: Cross-Scene Quest Verification

OPEN: Unzip the full archive. In GDevelop desktop, Open Project > From Your Computer > game.json; then Preview.

CONTROLS: WASD or arrow keys to move; touch elder, cottage entrance, key, exit. Press R to restart the entire quest.

EXPECTED FLOW:
  1. FOREST: Walk to elder (right side). Key is no longer on forest map.
  2. Elder says he lost the key in his COTTAGE.
  3. Walk to COTTAGE (center / slightly above).
  4. COTTAGE scene: walk to the key on left, pick it up.
  5. Walk to FOREST door at bottom-right to return.
  6. Approach elder again. He thanks you. Quest complete.
  7. Optional: re-enter cottage; key must not respawn.
  8. Press R to reset global quest variables and restart in forest.

ENGINE PROOF: GDevelop native events, two actual scenes, project-global variables. No custom JavaScript event runtime.
CAVEAT: Structural and simulated-event tests passed. Actual import/preview on your Mac GDevelop remains to be verified.
