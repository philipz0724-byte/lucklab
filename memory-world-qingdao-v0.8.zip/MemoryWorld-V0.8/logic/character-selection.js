const scene=runtimeScene,v=scene.getGame().getVariables(),o=n=>scene.getObjects(n)[0];
const down=k=>['1','2','3'].includes(k)?gdjs.evtTools.input.isKeyPressed(scene,'Num'+k)||gdjs.evtTools.input.isKeyPressed(scene,'Numpad'+k):gdjs.evtTools.input.isKeyPressed(scene,k);
const input=['1','2','3','Left','Right','a','d','e','Space','Return'];
if(!scene._select){scene._select={focus:1,keys:{}};for(const k of input)scene._select.keys[k]=down(k);for(const n of ['PreviewFeili','PreviewStrong','PreviewGuard'])o(n).pauseAnimation();}
const m=scene._select,keys={};for(const k of input){keys[k]=down(k)&&!m.keys[k];m.keys[k]=down(k);}
for(const n of ['SelectTitle','SelectSubtitle','Controls'])o(n).setX((960-o(n).getWidth())/2);
if(keys['1'])m.focus=1;else if(keys['2'])m.focus=2;else if(keys['3'])m.focus=3;
else if(keys.Left||keys.a)m.focus=(m.focus+1)%3+1;else if(keys.Right||keys.d)m.focus=m.focus%3+1;
o('SelectionBorder').setX([62,347,632][m.focus-1]);
o('SelectionDetail').setString(['非力：家附近出门，和孙天虎碰头，一起去接死猪。','孙天虎：先在附近等非力。由你走过去，也由你伸手闹他。','死猪：从商场交班开始，等他俩过来，然后一起吃串、开黑。'][m.focus-1]);
o('StartText').setString('E / Enter  以'+['非力','孙天虎','死猪'][m.focus-1]+'的视角开始');
o('StartText').setX((960-o('StartText').getWidth())/2);
if((keys.e||keys.Space||keys.Return)&&v.get('NextScene').getAsNumber()===0){
 // Clearing all story variables prevents a previous viewpoint leaking into this one.
 const state=['Perspective','MetStrong','ShiftDone','GuardJoined','Ordered','BaseSkewers','Ate','Roast','ExtraOrder','ExtraEaten','Paid','Payment','PaymentWho','SeaWalk','Bench','Stones','Role','MatchStep','Synergy','Finished','Stage','NextScene','ReturnFrom','HomePrank','SeaPrank','GuardLeadRemark','CafeRemark','PrankCount','IntroHome','IntroMall','IntroBBQ','IntroSea','IntroCafe'];
 for(const n of state)v.get(n).setNumber(0);
 v.get('Perspective').setNumber(m.focus);
 if(m.focus===3){v.get('MetStrong').setNumber(1);v.get('Stage').setNumber(1);}
 v.get('NextScene').setNumber(m.focus===3?2:1);
}
