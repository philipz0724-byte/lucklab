// Native GDevelop JavaScript event. State lives in declared global variables.
// This event supplies dialogue and breadcrumb following; native events own scene changes.
const scene = runtimeScene;
const globals = scene.getGame().getVariables();
const get = n => globals.get(n).getAsNumber();
const set = (n,v) => globals.get(n).setNumber(v);
const obj = n => scene.getObjects(n)[0];
const text = (n,s) => {const o=obj(n);if(o && o.getString()!==s)o.setString(s);};
const wrap = (s,max=39) => s.split('\n').map(line=>{
  let out='',width=0;for(const ch of line){const w=ch.charCodeAt(0)>255?1:0.54;if(width+w>max){out+='\n';width=0;}out+=ch;width+=w;}return out;
}).join('\n');
const player=obj('Player');
const place = scene.getName();
const sceneId = {Home:1,Mall:2,BBQ:3,Sea:4,Cafe:5}[place];
const stateNames=['MetStrong','GuardJoined','Ordered','BaseSkewers','Ate','Roast','ExtraOrder','ExtraEaten','Paid','Payment','SeaWalk','Bench','Stones','Role','MatchStep','Synergy','Finished','Stage','NextScene','ReturnFrom','HomePrank','SeaPrank','GuardMallRemark','GuardBBQRemark','GuardSeaRemark','GuardLeadRemark','CafeRemark','PrankCount'];
const local=scene.getVariables();
const down=k=>['1','2','3'].includes(k)
  ? gdjs.evtTools.input.isKeyPressed(scene,'Num'+k)||gdjs.evtTools.input.isKeyPressed(scene,'Numpad'+k)
  : gdjs.evtTools.input.isKeyPressed(scene,k);
if(!scene._mw){
  scene._mw={keys:{},dialog:null,page:0,trail:[],last:[player.getX(),player.getY()],direction:0,sitting:false,ending:place==='Cafe'&&!!get('Finished'),throwing:null,ambient:null,prank:null,freeTime:0,walked:0,prankCooldown:0,guardLead:false,cafeApproach:0};
  const m=scene._mw;
  // Prime all input keys on scene entry so held keys cannot activate another portal.
  for(const k of ['e','Space','Return','1','2','3','j','r','q','Escape'])m.keys[k]=down(k);
  const backwards=get('ReturnFrom')>sceneId;
  if(backwards)player.setPosition(814,362);
  set('ReturnFrom',0);
  for(const o of scene.getObjects('Solid'))o.hide();
  for(const n of ['Strong','Guard']){
    const o=obj(n);if(o && get(n==='Strong'?'MetStrong':'GuardJoined'))o.setPosition(Math.max(8,player.getX()-60*(n==='Strong'?1:2)),player.getY());
  }
  for(let i=0;i<60;i++)m.trail.push({x:Math.max(8,player.getX()-(59-i)*3),y:player.getY(),direction:0});
}
const m=scene._mw;
const dt=Math.min(.05,scene.getTimeManager().getElapsedTime()/1000);
const wasDialog=!!m.dialog;
const keys={};for(const k of ['e','Space','Return','1','2','3','j','r','q','Escape']){keys[k]=down(k)&&!m.keys[k];m.keys[k]=down(k);}
const pressed = keys.e||keys.Space||keys.Return;
const page=(who,s)=>({who,text:s});
const clearAside=()=>{m.ambient=null;m.prank=null;player.setAnimation(m.direction);for(const n of ['Strong','Guard']){const o=obj(n);if(o){o.setAnimation(0);o.pauseAnimation();}}};
const say=(pages,done=null,choices=null)=>{clearAside();m.dialog={pages,done,choices};m.page=0;m.selected=0;};
const close=()=>{const done=m.dialog&&m.dialog.done;m.dialog=null;m.page=0;if(done)done();};
const go=id=>{clearAside();set('ReturnFrom',sceneId);set('NextScene',id);};
const mark=(flag,value=1)=>set(flag,Math.max(get(flag),value));
const memories=()=>['MetStrong','GuardJoined','Ate','ExtraEaten','Paid','SeaWalk','Bench','Stones','Finished'].filter(n=>get(n)).length;
const pick=i=>{const choices=m.dialog&&m.dialog.choices;if(!choices||m.page!==m.dialog.pages.length-1||!choices[i])return;const fn=choices[i].run;m.dialog=null;if(fn)fn();};
const resetPrompt=()=>{
  const wasEnding=m.ending;m.ending=false;
  say([page('重新走一遍？','从齐东路附近家门口重新开始，会清空这次预览里的进度。')],null,[
    {label:'继续今晚',run:()=>{m.ending=wasEnding;}},
    {label:'重新开始',run:()=>{for(const n of stateNames)set(n,0);set('NextScene',1);}}
  ]);
};
if(keys.r&&!m.dialog)resetPrompt();
else if(m.ending){
  if(keys['1'])m.ending=false;
  else if(keys['2'])resetPrompt();
} else if(keys.j&&!m.dialog){
  const done=n=>get(n)?'已留下':'还没发生';
  say([
    page('今晚的小记 · 1 / 4',`齐东路附近和孙天虎碰面：${done('MetStrong')}。\n去商场接死猪下班：${done('GuardJoined')}。`),
    page('今晚的小记 · 2 / 4',`羊肉串：${done('Ate')}；加餐：${done('ExtraEaten')}。\n结账：${done('Paid')}。`),
    page('今晚的小记 · 3 / 4',`吹海风：${done('SeaWalk')}；坐椅子：${done('Bench')}。\n往海里扔石头：${done('Stones')}。`),
    page('今晚的小记 · 4 / 4',`非力、孙天虎、死猪，三人开黑：${done('Finished')}。\n一个普通又痛快的晚上。`)
  ]);
} else if(m.dialog){
  if(m.dialog.choices&&m.page===m.dialog.pages.length-1){
    if(keys['1'])pick(0);else if(keys['2'])pick(1);else if(keys['3'])pick(2);
  }else if(pressed){if(m.page<m.dialog.pages.length-1)m.page++;else close();}
}else if(pressed){
  const target=m.nearest;
  if(target){
    if(target.id==='strong'){
      if(!get('MetStrong'))say([
        page('孙天虎','非力，下来了？咱俩住这么近，你还让我等。'),
        page('非力','我才刚出门！你先站这儿两分钟就开始了。'),
        page('孙天虎','大个子磨磨蹭蹭的，走两步还得我来叫你。'),
        page('非力','我是你爹。走，去接死猪下班。'),
        page('孙天虎','行，齐东路这边出来再一起过去。他应该快交班了。')
      ],()=>{mark('MetStrong');mark('Stage',1);});
      else say([page('孙天虎',get('GuardJoined')?'人齐了，去吃串。你这大个子别把路灯挡了。':'他就在商场门口，走近点叫他。')]);
    }else if(target.id==='guard'){
      if(!get('MetStrong'))say([page('死猪','你先去跟那位碰个头，我这边马上交班。')]);
      else if(!get('GuardJoined'))say([
        page('死猪','等我一下，交班就走。你俩别堵在这儿，跟门神似的。'),
        page('孙天虎','我们来视察工作。你这保安当得挺有气势啊。'),
        page('死猪','我是你爹。视察完请我吃串。')
      ],null,[
        {label:'走，羊肉串安排',run:()=>say([page('非力','安排！肥瘦相间的，谁都别跟我抢。'),page('死猪','总算下班了。先吃串，吃完去网吧啊，别又绕远。')],()=>{mark('GuardJoined');mark('Stage',2);})},
        {label:'先让你嘚瑟一会',run:()=>say([page('非力','让你嘚瑟一会儿。下了班还不是得跟我们混。'),page('死猪','混就混，先吃饭。吃完开黑，我都惦记一天了。')],()=>{mark('GuardJoined');mark('Stage',2);})}
      ]);
      else say([page('死猪','吃串去。吃完得开两把，今天我可惦记着呢。')]);
    }else if(target.id==='home')say([page('非力','我和孙天虎家离得近，都在齐东路附近。碰面不用约什么大地方，楼下喊一声就行。'),page('孙天虎','少磨蹭两分钟，死猪下班咱俩正好到。')]);
    else if(target.id==='notice')say([page('非力','商场还亮着灯，门口有人提着袋子来来往往。'),page('孙天虎','别看了，咱们今天的购物清单只有羊肉串。')]);
    else if(target.id==='order'){
      if(get('Paid'))say([page('摊主','账结过了，下次再来。路上慢点啊。')]);
      else if(get('ExtraEaten')){
        const order=get('BaseSkewers')+' 串羊肉串，'+(get('ExtraOrder')===1?'后来又加了十串。':'后来又加了一份烤馒头。');
        say([page('摊主',order+'没漏吧？'),page('非力','没漏，老板结账。'),page('死猪','刚才谁一直喊我是你爹来着？现在表现一下。')],null,[
          {label:'我先结，下次你俩来',run:()=>say([page('非力','行，我先结。下次你俩可别装没听见。'),page('孙天虎','记着呢，走，海边消消食。'),page('摊主','收到了，慢走！')],()=>{mark('Paid');set('Payment',1);mark('Stage',3);})},
          {label:'三个人凑一起结',run:()=>say([page('孙天虎','来来来，一人凑点，别光顾着损。'),page('死猪','给你，串我可一串没少吃。'),page('摊主','收到了，慢走！')],()=>{mark('Paid');set('Payment',2);mark('Stage',3);})}
        ]);
      }else if(get('ExtraOrder'))say([page('摊主','加的已经送过去了，趁热吃，吃好了再过来结账。')]);
      else if(get('Ate'))say([page('死猪','好像还能再吃点。'),page('孙天虎','你这句从第一串就开始说了。'),page('摊主','再加点什么？')],null,[
        {label:'再加十串肥瘦羊肉串',run:()=>say([page('非力','再来十串，还要肥瘦相间的。'),page('死猪','这句听着最顺耳。')],()=>set('ExtraOrder',1))},
        {label:'加一份烤馒头',run:()=>say([page('非力','再加份烤馒头，烤脆点。'),page('孙天虎','可以，分着吃，吃完去海边。')],()=>set('ExtraOrder',2))}
      ]);
      else if(get('Ordered'))say([page('摊主','你们的串好了，坐旁边那桌趁热吃。')]);
      else say([page('摊主','三个小伙儿，吃点什么？'),page('非力','羊肉串！要肥瘦相间的，烤得滋滋冒油那种。')],null,[
        {label:'先来三十串',run:()=>say([page('摊主','好嘞，先上三十，不够再加。'),page('孙天虎','这才像样。刚才谁说随便吃两口来着？')],()=>{mark('Ordered');set('BaseSkewers',30);})},
        {label:'先来二十串，不够再加',run:()=>say([page('死猪','二十？你那大个子就吃这点？'),page('非力','先烤着，不够再加，急什么。')],()=>{mark('Ordered');set('BaseSkewers',20);})}
      ]);
    }else if(target.id==='table'){
      if(!get('Ordered'))say([page('孙天虎','先到烤炉前点串啊，总不能干坐着闻味儿。')]);
      else if(!get('Ate'))say([
        page('非力','肥的焦香，瘦的还嫩。撒上孜然，热气直往脸上扑。'),
        page('死猪','就这个味儿！这可比我今天的工作餐强多了。'),
        page('孙天虎','你先把嘴里的咽了再说，没人跟你抢。')
      ],null,[
        {label:'我是你爹，给我留两串',run:()=>say([page('非力','我是你爹！给我留两串。'),page('死猪','行，留给你，待会儿游戏里也这么能抢就行。'),page('非力','说归说，手上那两串给我放下。'),page('孙天虎','哈哈哈，嘴别停，串也别停。要不再加点？')],()=>{mark('Ate');mark('Roast',1);})},
        {label:'谁最后吃完谁收拾',run:()=>say([page('非力','谁最后吃完谁收拾。'),page('孙天虎','非力，你先把手里那四串放下再制定规则。'),page('死猪','吃串手速倒是挺快，待会儿打游戏别掉链子。'),page('非力','少贫。再加点，你俩还吃什么？')],()=>{mark('Ate');mark('Roast',2);})}
      ]);
      else if(get('ExtraOrder')&&!get('ExtraEaten'))say([page('摊主',get('ExtraOrder')===1?'加的十串来喽！':'加的烤馒头，趁脆吃！'),page('死猪','这回差不多了，真饱了。'),page('孙天虎','你上一轮也是这么说的。'),page('非力','吃完了，去老板那儿把账结了。')],()=>mark('ExtraEaten'));
      else say([page('死猪',get('Paid')?'账结了，海边坐一小会儿就去网吧啊。':get('ExtraEaten')?'吃好了，记得去老板那儿结账。':'还想加点，去烤炉前跟老板说一声。')]);
    }else if(target.id==='sea'){
      if(!get('SeaWalk'))say([
        page('非力','从团岛这边往栈桥附近走，海风一下就把烧烤摊的热气吹散了。'),
        page('孙天虎','你别站我前面，风都让你挡了。'),
        page('非力','挡风还不好？这身高总得派点用场。'),
        page('死猪','那你给我挡着。我先找个椅子坐坐，你俩别走太远。'),
        page('非力','行，就前面那排。坐会儿再去网吧。')
      ],()=>{mark('SeaWalk');mark('Stage',4);});
      else say([page('孙天虎','再吹会儿风？'),page('死猪','风都吹够了吧，走啊，网吧那三台还等着呢。')]);
    }else if(target.id==='bench'){
      m.seatRestore=['Player','Strong','Guard'].map(n=>({name:n,x:obj(n).getX(),y:obj(n).getY()}));m.sitting=true;
      const stand=()=>{m.sitting=false;for(const p of m.seatRestore){obj(p.name).setPosition(p.x,p.y);obj(p.name).setAnimation(0);}mark('Bench');mark('SeaWalk');mark('Stage',4);};
      say(get('Bench')?[page('孙天虎','再坐会儿呗。'),page('死猪','坐可以，别再拉着我绕圈了。待会儿得开黑。'),page('非力','知道了知道了，歇会儿就走。')]:[
        page('非力','这儿有椅子，坐会儿。'),page('孙天虎','往旁边挪挪。你腿长归腿长，也别占俩人的地儿。'),
        page('死猪','我站了一天了，这会儿谁叫我起来都不好使。'),page('非力','那就坐着。'),
        page('海边','三个人在椅子上挤了挤。海风迎面吹过来，聊两句，停一会儿，再随口接着聊。'),
        page('死猪','坐够了吧？去网吧啊，我位置都想好了。'),page('孙天虎','一说打游戏，你倒是愿意走了。'),page('死猪','那能一样吗？走走走。')
      ],stand);
    }else if(target.id==='stones'){
      const launch=(far)=>{m.throwing={time:0,x:player.getX()+28,y:player.getY()+22,ex:far?680:624,ey:far?196:246};};
      say([page('非力','捡一块小石头，掂两下，往没人的水面扔过去。'),page('孙天虎','比比谁扔得远？')],null,[
        {label:'使劲扔远点',run:()=>{launch(true);say([page('非力','石头划过一道弧线，咚地落进海里。'),page('死猪','行啊非力，胳膊没白长。'),page('非力','那是，爹练过。')],()=>mark('Stones'));}},
        {label:'随手一扔，听个响',run:()=>{launch(false);say([page('海边','扑通。水花一闪，很快就没了。'),page('孙天虎','就为了听这一下？'),page('非力','对啊，还挺爽。')],()=>mark('Stones'));}}
      ]);
    }else if(target.id==='pc'){
      if(get('Finished'))m.ending=true;
      else if(get('MatchStep')===0){
        say([page('死猪','三台挨着的，正好。今天打 LOL，谁跟谁走？'),page('孙天虎','先说好，别一打起来就只会喊我是你爹。')],null,[
          {label:'我打上路',run:()=>say([page('非力','我去上路，你们来就给你们留人头。'),page('孙天虎','行，你先别把自己留在那儿。')],()=>{set('Role',1);set('MatchStep',1);})},
          {label:'我打野来帮你们',run:()=>say([page('非力','我打野，等我来。'),page('死猪','这句话我记住了啊，别逛一整局。')],()=>{set('Role',2);set('MatchStep',1);})},
          {label:'我去下路',run:()=>say([page('非力','我去下路，咱俩一起。'),page('死猪','走，让他们见识一下咱俩的配合。')],()=>{set('Role',3);set('MatchStep',1);})}
        ]);
      }else if(get('MatchStep')===1){
        say([page('开黑 · 第一回合','小地图上队友打了信号。你们的声音盖过了旁边的键盘声。'),page('孙天虎','来来来，有机会！')],null,[
          {label:'看一眼小地图，一起上',run:()=>say([page('非力','等我到，一起。'),page('死猪','漂亮！早这么配合不就完了。')],()=>{set('Synergy',get('Synergy')+1);set('MatchStep',2);})},
          {label:'先喊一句：我是你爹',run:()=>say([page('非力','我是你爹！人来了人来了！'),page('孙天虎','哈哈哈，先走位！你的嘴比技能快。')],()=>set('MatchStep',2))}
        ]);
      }else if(get('MatchStep')===2){
        say([page('开黑 · 第二回合','一波打完，三个人都往椅子前沿凑了凑。'),page('死猪','这波推塔还是再追？')],null,[
          {label:'一起推塔',run:()=>say([page('非力','塔塔塔，先把塔推了。'),page('孙天虎','可以，今天有脑子了啊。')],()=>{set('Synergy',get('Synergy')+1);set('MatchStep',3);})},
          {label:'追两步，笑着收手',run:()=>say([page('非力','追一下……算了算了，回来。'),page('死猪','我都替你准备好笑话了，居然还知道回来。')],()=>set('MatchStep',3))}
        ]);
      }else{
        const result=get('Synergy')===2?'这把配合得顺，推掉基地的时候，三个人同时喊了出来。':get('Synergy')===1?'这一把打得有来有回。最后一波结束，旁边两个人还在复盘刚才谁最能喊。':'这一把笑得比打得还热闹。输赢刚跳出来，就已经有人在说下一把怎么打。';
        say([
          page('一局结束',result),
          page('孙天虎','差不多了，今天先到这儿。'),page('死猪','再来一把？我刚有手感。'),
          page('非力','这话你上把就说了。明天再打。'),page('孙天虎','走了走了。'),page('死猪','行吧，下次早点来，少绕两圈。'),
          page('网吧门口','退了游戏，推回椅子。三个人出门，嘴上还在说刚才那一波。'),
          page('非力','到家吱一声。下次还是老地方碰。'),page('孙天虎','行，家门口等你，少磨蹭。'),page('死猪','开黑也得叫我啊！'),
          page('回家的路','非力和孙天虎往齐东路附近慢慢走。串吃了，海风吹了，游戏也打够了。今晚，收工。')
        ],()=>{mark('Finished');mark('Stage',5);m.ending=true;});
      }
    }else if(target.id==='counter')say([page('网管','靠里那三台空着，坐一排吧。'),page('死猪','好嘞，再拿三瓶饮料。')]);
    else if(target.id==='forward'){
      if(place==='Home'){if(get('MetStrong'))go(2);else say([page('非力','先在家附近和孙天虎碰上，再一起去找死猪。')]);}
      if(place==='Mall'){if(get('GuardJoined'))go(3);else say([page('非力','死猪还没下班，去商场门口等他。')]);}
      if(place==='BBQ'){if(get('Paid'))go(4);else say([page('孙天虎',get('ExtraEaten')?'账还没结呢，去烤炉前找老板。':get('Ate')?'再加点，吃好了结账，咱再走。':'先点串，到左边小圆桌吃。吃好了再去海边。')]);}
      if(place==='Sea'){if(get('Bench'))go(5);else say([page('非力','先在中间那排椅子上坐一下，刚才都说好了。'),page('死猪','行行行，坐完就去网吧。')]);}
    }else if(target.id==='back')go(sceneId-1);
  }
}
// Update movement lock before native WASD events run.
const locked=!!m.dialog||m.ending||get('NextScene')!==0;
player.activateBehavior('TopDownMovement',!locked);
local.get('DialogOpen').setNumber(locked?1:0);
const [lx,ly]=m.last;const dx=player.getX()-lx,dy=player.getY()-ly;
let direction=m.direction||0;
if(!m.sitting&&(Math.abs(dx)+Math.abs(dy)>0.1)){direction=Math.abs(dx)>Math.abs(dy)?(dx>0?3:2):(dy>0?0:1);player.setAnimation(direction);player.playAnimation();}else {if(!m.sitting)player.setAnimation(direction);player.pauseAnimation();}
m.direction=direction;m.last=[player.getX(),player.getY()];
// Passing remarks never set DialogOpen or move the player's collision body.
// One-shot remarks are global; revisiting a scene does not restart the same joke.
m.prankCooldown=Math.max(0,m.prankCooldown-dt);
if(locked||wasDialog){m.freeTime=0;}else{
 m.freeTime+=dt;const travelled=Math.hypot(dx,dy);if(travelled<30)m.walked+=travelled;
}
const aside=(flag,pages)=>{if(flag)mark(flag);m.ambient={pages,time:0};};
const prank=(flag,night=false)=>{
 if(flag)mark(flag);mark('PrankCount',get('PrankCount')+1);m.ambient=null;
 m.prank={time:0,actionTime:0,choice:0,responseTime:0,night,kind:night?'拍一下':(get('PrankCount')%2?'掐一下':'拍一下')};
 m.prankCooldown=10;
};
if(!locked){
 if(m.ambient){m.ambient.time+=dt;if(m.ambient.time>=m.ambient.pages.length*3.5)m.ambient=null;}
 if(m.prank){
  const p=m.prank;p.time+=dt;p.actionTime+=dt;
  if(!p.choice&&(keys['1']||keys['2'])){p.choice=keys['1']?1:2;p.actionTime=.35;}
  if(p.choice)p.responseTime+=dt;
  if((p.choice&&p.responseTime>3.5)||p.time>7)m.prank=null;
 }
 if(keys.q&&get('MetStrong')&&m.prankCooldown===0&&player.getX()>70)prank(null);
 if(!m.prank&&!m.ambient&&m.freeTime>1){
  if(place==='Home'&&get('MetStrong')&&!get('HomePrank')&&m.walked>95)prank('HomePrank');
  else if(place==='Mall'&&get('GuardJoined')&&!get('GuardMallRemark')&&m.walked>90)aside('GuardMallRemark',[page('死猪','吃完就去网吧啊，可别又绕一大圈。'),page('孙天虎','刚下班就惦记着开机，你可真行。')]);
  else if(place==='BBQ'&&get('Paid')&&!get('GuardBBQRemark'))aside('GuardBBQRemark',[page('死猪','吃饱了没？我都想好第一把玩什么了。'),page('非力','先去海边坐一会儿，近。')]);
  else if(place==='Sea'&&get('GuardJoined')&&!get('GuardSeaRemark')&&m.walked>90)aside('GuardSeaRemark',[page('死猪','还走啊？找个椅子坐坐，坐完去网吧。'),page('孙天虎','你这一路，就记着网吧了。')]);
  else if(place==='Sea'&&get('Bench')&&!get('SeaPrank')&&player.getX()<670)prank('SeaPrank',true);
  else if(place==='Sea'&&get('Bench')&&player.getX()>720&&!get('GuardLeadRemark'))aside('GuardLeadRemark',[page('死猪','网吧就在前面！快点快点，这回跟我走。'),page('非力','一说开黑，你这腿倒是不累了。')]);
  else if(place==='Cafe'&&get('GuardJoined')&&!get('CafeRemark')&&!get('Finished'))aside('CafeRemark',[page('死猪','到了到了！里面三台挨着的，我去占个位置。'),page('孙天虎','刚才还走不动呢，现在比谁都快。')]);
 }
}else if(m.ending||get('NextScene'))clearAside();
const head=m.trail[m.trail.length-1];
if(!m.sitting&&Math.hypot(player.getX()-head.x,player.getY()-head.y)>=3){m.trail.push({x:player.getX(),y:player.getY(),direction});if(m.trail.length>350)m.trail.shift();}
const trailAt=distance=>{let rem=distance;for(let i=m.trail.length-1;i>0;i--){const a=m.trail[i],b=m.trail[i-1];const len=Math.hypot(a.x-b.x,a.y-b.y);if(len>=rem&&len>0){const f=rem/len;return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,direction:a.direction};}rem-=len;}return m.trail[0];};
const moveBuddy=(o,p,speed=300)=>{
 const x=p.x-o.getX(),y=p.y-o.getY(),distance=Math.hypot(x,y),step=Math.min(distance,speed*dt);
 if(distance>.5){o.setPosition(o.getX()+x/distance*step,o.getY()+y/distance*step);o.setAnimation(Math.abs(x)>Math.abs(y)?(x>0?3:2):(y>0?0:1));o.playAnimation();}
 else {o.setAnimation(p.direction===undefined?0:p.direction);o.pauseAnimation();}
 return distance;
};
const clearFeet=(x,y)=>!scene.getObjects('Solid').some(o=>x+41>o.getX()&&x+15<o.getX()+o.getWidth()&&y+66>o.getY()&&y+51<o.getY()+o.getHeight());
if(place==='Sea'&&get('Bench')&&player.getX()>720&&player.getY()>320&&obj('Guard').getX()>595)m.guardLead=true;
if(locked||dx<-.5||player.getX()<680||player.getY()<320)m.guardLead=false;
for(const [n,flag,offset] of [['Strong','MetStrong',55],['Guard','GuardJoined',110]]){
 const o=obj(n);if(!o)continue;
 if(get(flag)&&!m.sitting&&!m.ending){
  const prankTarget={x:Math.max(8,player.getX()-43),y:player.getY()+6,direction:3};
  if(n==='Strong'&&m.prank&&m.prank.actionTime<1.5&&clearFeet(prankTarget.x,prankTarget.y)){
   const distance=moveBuddy(o,prankTarget,360);
   if(distance<18&&m.prank.actionTime>.35){o.setAnimation(5);o.playAnimation();}
  }else if(n==='Guard'&&m.guardLead){
   moveBuddy(o,{x:Math.min(861,player.getX()+68),y:player.getY(),direction:3},270);
  }else if(n==='Guard'&&place==='Cafe'&&!get('Finished')&&!locked){
   // Approach the PCs through the clear aisle above the lower desk row.
   if(!m.cafeApproach)m.cafeApproach=player.getX()>680?3:1;
   if(m.cafeApproach===1){if(moveBuddy(o,{x:60,y:286,direction:1},270)<5)m.cafeApproach=2;}
   else if(m.cafeApproach===2){if(moveBuddy(o,{x:588,y:286,direction:3},270)<5)m.cafeApproach=3;}
   else {moveBuddy(o,{x:588,y:352,direction:2},270);}
  }else if(!locked)moveBuddy(o,trailAt(offset));
  if(n==='Guard'&&m.ambient&&m.ambient.pages[Math.floor(m.ambient.time/3.5)]?.who==='死猪'&&Math.hypot(dx,dy)<.1&&!m.guardLead&&place!=='Cafe'){o.setAnimation(5);o.pauseAnimation();}
 }
 o.setZOrder(Math.round(o.getY()+66));
 const label=obj('Label'+n);if(label){label.setPosition(o.getX()-6,o.getY()-15);label.setZOrder(500);}
 if(label)text('Label'+n,n==='Strong'?'孙天虎':'死猪');
 const visible=!(place==='Home'&&n==='Guard'&&!get('GuardJoined'));o.hide(!visible);if(label)label.hide(!visible);
}
if(m.prank&&m.prank.actionTime>.35&&m.prank.actionTime<1.5){
 if(m.prank.choice===1){player.setAnimation(5);player.playAnimation();}
}
if(m.sitting){
 for(const [n,x] of [['Player',348],['Strong',413],['Guard',478]]){const o=obj(n);o.setPosition(x,356);o.setAnimation(4);o.pauseAnimation();o.setZOrder(425);const label=obj('Label'+n);if(label)label.setPosition(x,341);}
}
if(obj('BenchLabel'))obj('BenchLabel').hide(m.sitting);
text('LabelPlayer','非力');obj('LabelPlayer').setPosition(player.getX(),player.getY()-15);
player.setZOrder(Math.round(player.getY()+66));
if(obj('Stone')){
 obj('Stone').hide();obj('Ripple').hide();
 if(m.throwing){
  const t=m.throwing;t.time+=scene.getTimeManager().getElapsedTime()/1000;
  if(t.time<.9){const f=t.time/.9;obj('Stone').hide(false);obj('Stone').setPosition(t.x+(t.ex-t.x)*f,t.y+(t.ey-t.y)*f-100*Math.sin(Math.PI*f));}
  else if(t.time<1.9){obj('Ripple').hide(false);obj('Ripple').setPosition(t.ex-24,t.ey-8);obj('Ripple').setOpacity(Math.round(255*(1-(t.time-.9))));}
  else m.throwing=null;
 }
}
// Only story destinations are targeted after companions join; followers never steal the action key.
let targets=[];
const target=(id,label,x,y,r=88)=>targets.push({id,label,x,y,r});
if(place==='Home'){
 if(!get('MetStrong')){const o=obj('Strong');target('strong','和孙天虎碰头',o.getX()+28,o.getY()+55);}
 target('home','看看家附近的路口',150,350,60);target('forward','一起去商场接死猪',900,437,80);
}else if(place==='Mall'){
 if(!get('GuardJoined')){const o=obj('Guard');target('guard','等死猪下班',o.getX()+28,o.getY()+55);}
 target('notice','看看商场门口',172,295,65);target('forward','去路边烧烤',900,437,80);target('back','回齐东路附近',45,438,60);
}else if(place==='BBQ'){target('order',get('Paid')?'跟老板打个招呼':get('ExtraEaten')?'结账':get('Ate')?'加点餐':'点羊肉串',426,326,90);target('table',get('ExtraOrder')&&!get('ExtraEaten')?'吃加的餐':'坐下吃串、聊两句',145,372,82);target('forward','去海边',905,438);target('back','回商场',45,438,60);
}else if(place==='Sea'){target('sea','吹吹海风',185,342,75);target('bench','三个人坐椅子上歇会儿',454,431,90);target('stones','往海里扔石头（可选）',658,346,72);target('forward','去网吧开黑',905,438);target('back','回烧烤摊',45,438,60);
}else{target('pc',get('Finished')?'看看今晚的结尾':get('MatchStep')?'继续这局 LOL':'坐下，三人开黑',357,427,95);target('counter','跟网管打招呼',805,421,80);target('back','回海边走走',48,438,60);}
const px=player.getX()+28,py=player.getY()+60;
let nearest=null,dist=Infinity;for(const t of targets){const v=Math.hypot(px-t.x,py-t.y);if(v<t.r&&v<dist){nearest=t;dist=v;}}
m.nearest=nearest;
if(obj('StonesLabel'))obj('StonesLabel').hide(!!m.dialog&&nearest&&nearest.id==='stones');
const tasks=place==='Home'?(!get('MetStrong')?'在家附近和孙天虎碰面，再一起去找死猪':'孙天虎来了，往右走，一起去商场'):
 place==='Mall'?(!get('GuardJoined')?'走到商场门前，等死猪下班':'人齐了！往右走，去路边烧烤'):
 place==='BBQ'?(!get('Ordered')?'走近烤炉，点肥瘦相间的羊肉串':!get('Ate')?'到左边小圆桌，吃串、互相损两句':!get('ExtraOrder')?'没吃够？到烤炉前找老板加点餐':!get('ExtraEaten')?'加的餐好了，回左边小圆桌继续吃':!get('Paid')?'吃好了，去烤炉前找老板结账':'账结好了，往右去海边'):
 place==='Sea'?(!get('Bench')?'在中间长椅坐会儿；也可以去栏杆边吹风、扔石头':'风吹够了？往右去网吧，扔石头也可以再玩'):
 get('Finished')?'今晚已完成。可以回海边、按 J 看小记，或按 R 重玩':get('MatchStep')?'走近中间那排电脑，按 E 继续这局':'到中间那排电脑旁，和朋友一起打 LOL';
text('Task',tasks);text('Counter',`回忆 ${memories()} / 9`);
text('Prompt',!locked&&nearest?'[ E ] '+nearest.label:'');
if(m.dialog){
 const p=m.dialog.pages[m.page];text('Speaker',p.who);text('Dialogue',wrap(p.text));
 const final=m.page===m.dialog.pages.length-1;
 text('Choices',final&&m.dialog.choices?m.dialog.choices.map((c,i)=>`${i+1}  ${c.label}`).join('    '):'E / 空格 / Enter  继续');
}else if(m.prank){
 const p=m.prank;
 text('Speaker',p.choice?'非力':'孙天虎 · '+p.kind);
 text('Dialogue',wrap(p.choice===1?(p.night?'看不见我，还拍得这么准？\n你侧了侧身，笑着躲开他的手。':'又来！你这手就不能闲一会儿？\n你侧了侧身，笑着躲开他的手。'):p.choice===2?(p.night?'我是你爹，认声音就行。\n孙天虎笑出了声，手也收了回去。':'我是你爹！再掐我，我可还手了啊。\n孙天虎笑着把手收了回去。'):(p.night?'天都黑了，非力人呢？我怎么快看不见你了。\n孙天虎笑着拍了拍你的胳膊。':p.kind==='掐一下'?'孙天虎凑过来，伸手掐了一下你的胳膊。\n“走这么快干什么，等等你爹。”':'孙天虎顺手拍了你一下，笑着又凑过来。\n“怎么不说话了，大个子？”')));
 text('Choices',p.choice?'可以继续走；靠近地点按 E 互动':'1  侧身躲一下    2  回嘴    可以继续走，靠近地点按 E 互动');
}else if(m.ambient){
 const p=m.ambient.pages[Math.floor(m.ambient.time/3.5)];
 text('Speaker',p.who+' · 路上闲聊');text('Dialogue',wrap(p.text));
 text('Choices','可以继续走；靠近地点按 E 互动    Q 和孙天虎闹两句');
}else{
 text('Speaker',get('Finished')?'今晚，就这样挺好':'今夜无事，和朋友一起。');
 text('Dialogue',get('Finished')?'青岛的那些夜晚 · V0.6\n今晚已结束。这里可以继续自由走走，或重新玩一次。':wrap(tasks+'。\n走近人物或地点，看到提示后按 E 互动。'));
 text('Choices','WASD / 方向键 走动    E 互动    Q 打闹    J 小记    R 重玩');
}
for(const n of ['EndShade','EndTitle','EndSubtitle','EndBody','EndChoices','EndTag'])if(obj(n))obj(n).hide(!m.ending);
if(m.ending){
 text('EndTitle','青岛的那些夜晚');text('EndSubtitle','今晚，收工。下次，老地方。');
 text('EndBody','非力  ·  孙天虎  ·  死猪\n\n家门口碰头，接上下班的朋友。\n吃串加餐，结完账，去海边坐一会儿。\n开黑打够了，互相损着回家。');
 text('EndChoices','1  回到游戏里自由走走       2  重新过这个夜晚');text('EndTag','MEMORY WORLD  /  V0.6  /  今晚已完成');
 for(const n of ['EndTitle','EndSubtitle','EndBody','EndChoices','EndTag'])obj(n).setX((960-obj(n).getWidth())/2);
}
