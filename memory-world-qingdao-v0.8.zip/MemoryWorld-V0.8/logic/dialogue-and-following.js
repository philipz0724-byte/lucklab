// Native GDevelop event. Object names identify people; Perspective identifies control.
// Story flags survive native scene changes and are reset only when returning to selection.
const scene=runtimeScene,globals=scene.getGame().getVariables(),local=scene.getVariables();
const get=n=>globals.get(n).getAsNumber(),set=(n,v=1)=>globals.get(n).setNumber(v);
const obj=n=>scene.getObjects(n)[0],text=(n,s)=>{const o=obj(n);if(o&&o.getString()!==s)o.setString(s);};
const people=['Player','Strong','Guard'],names={Player:'非力',Strong:'孙天虎',Guard:'死猪'};
const pov=get('Perspective')||1,controlled=people[pov-1],player=obj(controlled),me=names[controlled];
const byPov=(a,b,c)=>[a,b,c][pov-1],other=pov===2?'非力':'孙天虎';
const place=scene.getName(),sceneId={Home:1,Mall:2,BBQ:3,Sea:4,Cafe:5}[place];
const stateNames=['Perspective','MetStrong','ShiftDone','GuardJoined','Ordered','BaseSkewers','Ate','Roast','ExtraOrder','ExtraEaten','Paid','Payment','PaymentWho','SeaWalk','Bench','Stones','Role','MatchStep','Synergy','Finished','Stage','NextScene','ReturnFrom','HomePrank','SeaPrank','GuardLeadRemark','CafeRemark','PrankCount','IntroHome','IntroMall','IntroBBQ','IntroSea','IntroCafe'];
const wrap=(s,max=39)=>s.split('\n').map(line=>{let out='',width=0;for(const c of line){const w=c.charCodeAt(0)>255?1:.54;if(width+w>max){out+='\n';width=0;}out+=c;width+=w;}return out;}).join('\n');
const input=['e','Space','Return','1','2','3','j','r','q'];
const down=k=>['1','2','3'].includes(k)?gdjs.evtTools.input.isKeyPressed(scene,'Num'+k)||gdjs.evtTools.input.isKeyPressed(scene,'Numpad'+k):gdjs.evtTools.input.isKeyPressed(scene,k);
const visible=n=>n===controlled||!(place==='Home'&&n==='Guard'&&!get('GuardJoined'))&&!(place==='Mall'&&pov===3&&!get('ShiftDone')&&n!=='Guard');
const follows=n=>n!==controlled&&visible(n)&&(n==='Guard'?get('GuardJoined'):get('MetStrong')&&(pov!==3||get('GuardJoined')));
if(!scene._mw){
 scene._mw={keys:{},dialog:null,page:0,trail:[],last:[0,0],direction:0,sitting:false,ending:place==='Cafe'&&!!get('Finished'),throwing:null,ambient:null,prank:null,freeTime:0,walked:0,prankCooldown:0,guardLead:false,cafeApproach:0,controlled};
 const m=scene._mw;for(const k of input)m.keys[k]=down(k);
 if(place==='Home'&&!get('MetStrong')){player.setPosition(100,390);obj(pov===2?'Player':'Strong').setPosition(300,300);}
 else if(place==='Mall'&&pov===3&&!get('GuardJoined')){player.setPosition(444,260);obj('Player').setPosition(216,390);obj('Strong').setPosition(134,390);}
 else player.setPosition(get('ReturnFrom')>sceneId?814:216,390);
 set('ReturnFrom',0);let gap=0;
 for(const n of people){obj(n).activateBehavior('TopDownMovement',false);if(follows(n)){gap+=82;obj(n).setPosition(Math.max(8,player.getX()-gap),player.getY());}obj(n).pauseAnimation();obj('Label'+n).setColor(n===controlled?'255;224;165':'240;238;230');}
 for(const s of scene.getObjects('Solid'))s.hide();
 for(let i=0;i<90;i++)m.trail.push({x:Math.max(8,player.getX()-(89-i)*3),y:player.getY(),direction:0});
 m.last=[player.getX(),player.getY()];
}
const m=scene._mw,dt=Math.min(.05,scene.getTimeManager().getElapsedTime()/1000),wasDialog=!!m.dialog;
const keys={};for(const k of input){keys[k]=down(k)&&!m.keys[k];m.keys[k]=down(k);}
const E=keys.e||keys.Space||keys.Return,page=(who,text)=>({who,text}),thought=s=>page(me+' · 心里',s);
const clearAside=()=>{m.ambient=null;m.prank=null;for(const n of people){obj(n).setAnimation(n===controlled?m.direction:0);obj(n).pauseAnimation();}};
const say=(pages,done=null,choices=null)=>{clearAside();m.dialog={pages,done,choices};m.page=0;};
const close=()=>{const done=m.dialog?.done;m.dialog=null;m.page=0;m.freeTime=0;if(done)done();};
const pick=i=>{const d=m.dialog;if(!d?.choices||m.page!==d.pages.length-1||!d.choices[i])return;m.dialog=null;m.freeTime=0;d.choices[i].run();};
const go=id=>{clearAside();set('ReturnFrom',sceneId);set('NextScene',id);};
const mark=(n,v=1)=>set(n,Math.max(v,get(n)));
const stand=()=>{m.sitting=false;for(const p of m.seatRestore){obj(p.name).setPosition(p.x,p.y);obj(p.name).setAnimation(0);}m.last=[player.getX(),player.getY()];m.freeTime=0;};
const resetPrompt=()=>{const ending=m.ending;m.ending=false;say([page('换个视角再来？','会清空这一晚的进度，回到三个人的选择画面。')],null,[{label:'继续今晚',run:()=>m.ending=ending},{label:'重新选人',run:()=>{for(const n of stateNames)set(n,0);set('NextScene',6);}}]);};
// Each viewpoint has a distinct entry and private observations. Guard starts at work.
if(!get('Intro'+place)){
 set('Intro'+place);
 const intro={
  Home:[byPov('我和孙天虎家离得近。出门走几步，他已经在那儿了。','我先下来了。非力家就在边上，喊他一声就行。','他俩住这一片。今天下班以后，才跟他们碰上。')],
  Mall:[byPov('和孙天虎到了商场。死猪还在门口，等他交完班就走。','非力跟在旁边。死猪还没换班，我先过去招呼一声。','站一天了。交班本签完，等非力他们过来。')],
  BBQ:[byPov('就想吃肥瘦相间的羊肉串。先点上，不够再加。','先坐一会儿，非力已经盯上烤炉了。','闻着就饿了。吃完再找地方坐。')],
  Sea:[byPov('到海边了，找个椅子坐会儿。孙天虎的手又闲不住。','海风挺舒服。非力就在旁边，顺手拍他一下。','腿有点累。中间有椅子，过去坐着。')],
  Cafe:[byPov('三台挨着的电脑，正好。今晚再打一把。','坐非力旁边。他要是乱冲，我可得骂他。','到了。那三台空着，先占上。')]
 };
 if(!m.ending)say(intro[place].map(thought));
}
if(keys.r&&!m.dialog&&!m.sitting)resetPrompt();
else if(m.ending){if(keys['1'])m.ending=false;else if(keys['2'])resetPrompt();}
else if(m.sitting&&!m.dialog){if(E)stand();}
else if(keys.j&&!m.dialog){
 const done=n=>get(n)?'已经做了':'还没做';
 say([page(me+'的今晚',pov===3?'非力和孙天虎先在家附近碰头，那时我还在商场上班。':`家附近碰头：${done('MetStrong')}。\n商场接上死猪：${done('GuardJoined')}。`),page('吃串',`吃串：${done('Ate')}；加餐：${done('ExtraEaten')}。\n结账：${get('Paid')?(get('Payment')===2?'三个人凑的':names[people[get('PaymentWho')-1]]+'先结的'):'还没结'}。`),page('海边和网吧',`坐椅子：${done('Bench')}；扔石头：${done('Stones')}。\n一起开黑：${done('Finished')}。`)]);
}else if(m.dialog){if(m.dialog.choices&&m.page===m.dialog.pages.length-1){if(keys['1'])pick(0);else if(keys['2'])pick(1);else if(keys['3'])pick(2);}else if(E){if(m.page<m.dialog.pages.length-1)m.page++;else close();}}
else if(E&&m.nearest){
 const id=m.nearest.id;
 if(id==='meet'){
  say(pov===2?[page('孙天虎','非力，下来这么慢，干啥呢？'),page('非力','你他妈别叭叭，我这不来了。'),page('孙天虎','走，找死猪去。')]:[page('孙天虎','非力，来了？'),page('非力','来了。你他妈手别欠，刚见面就掐。'),page('孙天虎','我是你爹。走了。')],()=>{mark('MetStrong');mark('Stage',1);});
 }else if(id==='shift'){
  say([page('交班','核对完交班本，把钥匙递给接班的同事。'),thought('终于下班了。看看他俩到哪儿了。')],()=>{set('ShiftDone');obj('Player').setPosition(216,390);obj('Strong').setPosition(134,390);});
 }else if(id==='guard'||id==='friends'){
  const join=()=>{set('ShiftDone');mark('GuardJoined');mark('Stage',2);};
  say(pov===3?[page('孙天虎','死猪，走了。'),page('非力','饿了，先吃串。')]:[page('死猪','等会儿，交班。'),page('孙天虎','赶紧的，非力都饿了。'),page('死猪','走。')],null,[
   {label:'走，先吃串',run:()=>say([page(me,byPov('老板那边走，先吃串。','走，先把串吃了。','走。'))],join)},
   {label:byPov('你他妈终于下班了','还以为你要住这儿','你俩他妈终于来了'),run:()=>say([page(me,byPov('你他妈终于下班了。','还以为你要住这儿呢。','你俩他妈终于来了。')),page(other,pov===3?'走了走了。':'别叭叭了，走。')],join)}
  ]);
 }else if(id==='home')say([thought(byPov('孙天虎家就在附近。以后出来还在这儿碰头。','等非力也不用跑远，就在家附近。','他俩家离得是真近。'))]);
 else if(id==='notice')say([thought(byPov('商场还亮着灯。死猪一交完班，我们就走。','门口人来人往，站边上等他。','这一班算完了。腿酸，先找口吃的。'))]);
 else if(id==='order'){
  if(get('Paid'))say([page('摊主','结过了，慢走啊。')]);
  else if(get('ExtraEaten')){
   const order=get('BaseSkewers')+'串羊肉串，'+(get('ExtraOrder')===1?'又加了十串。':'又加了一份烤馒头。');
   say([page('摊主',order),page(me,pov===3?'结账。':'老板，结账。')],null,[
    {label:'我先结，下次你俩来',run:()=>say([page(me,pov===3?'我先结。':'我先结，下次你俩来。'),page(other,'行，下次我来。'),page('摊主','收到了！')],()=>{set('Paid');set('Payment',1);set('PaymentWho',pov);mark('Stage',3);})},
    {label:'三个人凑一起结',run:()=>say([page(me,pov===3?'凑一起。':'来，一人凑点。'),page('摊主','收到了，慢走！')],()=>{set('Paid');set('Payment',2);set('PaymentWho',0);mark('Stage',3);})}
   ]);
  }else if(get('ExtraOrder'))say([page('摊主','加的好了，在你们桌上。')]);
  else if(get('Ate'))say([page(me,pov===3?'再加点。':'还吃不吃？再加点。'),page('摊主','加什么？')],null,[
   {label:'再加十串肥瘦羊肉串',run:()=>say([page(me,pov===3?'十串，肥瘦的。':'再来十串肥瘦的。')],()=>set('ExtraOrder',1))},
   {label:'加一份烤馒头',run:()=>say([page(me,pov===3?'烤馒头。':'加份烤馒头，烤脆点。')],()=>set('ExtraOrder',2))}
  ]);
  else if(get('Ordered'))say([page('摊主','串好了，到左边那桌吃吧。')]);
  else say([page('摊主','吃点什么？'),page(me,pov===3?'羊肉串，肥瘦的。':'羊肉串，要肥瘦相间的。')],null,[
   {label:'先来三十串',run:()=>say([page(me,pov===3?'三十。':'先来三十串。'),page('摊主','好嘞！')],()=>{set('Ordered');set('BaseSkewers',30);})},
   {label:'先来二十串，不够再加',run:()=>say([page(me,pov===3?'先二十。':'先来二十，不够再加。'),page(other,'行，先烤着。')],()=>{set('Ordered');set('BaseSkewers',20);})}
  ]);
 }else if(id==='table'){
  if(!get('Ordered'))say([page(other,'先点串啊，坐这儿干闻味儿？')]);
  else if(!get('Ate'))say([page('烧烤摊','羊肉串刚离火，肥肉边上焦焦的，孜然味儿直往鼻子里钻。'),thought(byPov('就爱这个肥瘦相间的。先拿两串。','非力一伸手拿好几串，我也赶紧拿。','趁热吃。听他俩边吃边骂。'))],null,[
   {label:byPov('我是你爹，给我留两串','非力，你他妈少抢两串','拿两串，听他俩闹'),run:()=>say(pov===3?[page('孙天虎','非力，给我留点。'),page('非力','你他妈别叭叭，这不还有吗。')]:[page(me,byPov('我是你爹，给我留两串。','非力，你他妈少抢两串。','')),page(other,byPov('你他妈自己手里还攥着呢。','滚蛋，自己拿。',''))],()=>{set('Ate');set('Roast',1);})},
   {label:byPov('你他妈别叭叭，赶紧吃','我是你爹，串给我放下','吃串，懒得接话'),run:()=>say(pov===3?[thought('懒得接话。先把手里这串吃完。')]:[page(me,byPov('你他妈别叭叭，赶紧吃。','我是你爹，串给我放下。','')),page(other,byPov('操，你吃你的。','你他妈自己拿啊。',''))],()=>{set('Ate');set('Roast',2);})}
  ]);
  else if(get('ExtraOrder')&&!get('ExtraEaten'))say([page('摊主',get('ExtraOrder')===1?'加的十串！':'烤馒头好了！'),page('烧烤摊','三个人分着吃完，把签子归到一块儿。'),page(me,pov===3?'饱了。':'差不多了，结账去。')],()=>set('ExtraEaten'));
  else say([thought(get('Paid')?'吃饱了，去海边坐会儿。':get('ExtraEaten')?'还没结账，去找老板。':'还能再吃点，去加一单。')]);
 }else if(id==='sea'){
  say([page('海边','海风迎面吹来，刚才烧烤摊的热乎劲儿慢慢散了。'),thought(byPov('站一会儿挺舒服，旁边这俩人也没急着说话。','非力站旁边。我拍他一下，他回头就骂，俩人都笑。','风挺凉快。中间有椅子，过去坐。'))],()=>{set('SeaWalk');mark('Stage',4);});
 }else if(id==='bench'){
  m.seatRestore=people.map(name=>({name,x:obj(name).getX(),y:obj(name).getY()}));m.sitting=true;
  say(get('Bench')?[thought(byPov('再坐一会儿，想走了再起。','往椅背上一靠，继续吹风。','坐着就行。'))]:[page('非力','这儿坐会儿。'),page('孙天虎','非力，往那边挪挪。'),page('非力','你他妈屁股多大啊。'),page('海边','三个人挤着坐下。聊两句，停一会儿，吹着海风。'),thought(byPov('这会儿也没什么非干不可的事。再坐会儿。','非力就在边上，死猪坐另一头。谁想起什么就说一句。','终于坐下了。先歇会儿，网吧也不急这几分钟。'))],()=>{set('Bench');set('SeaWalk');mark('Stage',4);});
 }else if(id==='stones'){
  const launch=far=>{m.throwing={time:0,x:player.getX()+36,y:player.getY()+42,ex:far?735:690,ey:far?110:170};say([page('海边',far?'石头划了道弧线，扑通一声落进海里。':'随手一扔，扑通。水花一下就散了。'),page(me,byPov(far?'看见没，爹练过。':'就听个响，挺爽。',far?'非力，看见没？':'听着还挺响。',far?'还行。':'嗯。'))],()=>set('Stones'));};
  say([thought(byPov('捡块小石头，掂两下，往没人的水面扔。','捡一块，扔远点给非力看看。','顺手捡一块，扔完就回去坐着。'))],null,[{label:'用力扔远点',run:()=>launch(true)},{label:'随手扔，听个响',run:()=>launch(false)}]);
 }else if(id==='pc'){
  if(get('Finished'))m.ending=true;
  else if(!get('MatchStep'))say([page('网吧','三台挨着的电脑。耳机一戴，椅子往前拉。'),page(other,'你打哪儿？')],null,[
   {label:'我打上路',run:()=>say([page(me,pov===3?'上路。':'我去上路。'),page(other,'行，别他妈乱冲。')],()=>{set('Role',1);set('MatchStep',1);})},
   {label:'我打野',run:()=>say([page(me,pov===3?'打野。':'我打野，等我来。'),page(other,'别光他妈逛街。')],()=>{set('Role',2);set('MatchStep',1);})},
   {label:'我去下路',run:()=>say([page(me,pov===3?'下路。':'我去下路。'),page(other,'行，走。')],()=>{set('Role',3);set('MatchStep',1);})}
  ]);
  else if(get('MatchStep')===1)say([page('开黑 · 第一回合','小地图上亮了信号，旁边的人敲了两下桌子。'),page(other,'来来来，这边！')],null,[
   {label:'等队友，一起上',run:()=>say([page(me,pov===3?'来了。':'等我，一起。'),page(other,'漂亮。')],()=>{set('Synergy',get('Synergy')+1);set('MatchStep',2);})},
   {label:'先喊一句：我是你爹',run:()=>say([page(me,'我是你爹！'),page(other,'你他妈别叭叭，看人！')],()=>set('MatchStep',2))}
  ]);
  else if(get('MatchStep')===2)say([page('开黑 · 第二回合','一波打完，前面只剩座塔。')],null,[
   {label:'一起推塔',run:()=>say([page(me,pov===3?'推。':'塔塔塔，别追了。')],()=>{set('Synergy',get('Synergy')+1);set('MatchStep',3);})},
   {label:'追两步，再回来',run:()=>say([page(other,'回来，别他妈送了。'),page(me,pov===3?'回了。':'回了回了。')],()=>set('MatchStep',3))}
  ]);
  else{
   const result=get('Synergy')===2?'基地一倒，三个人同时喊了出来。':get('Synergy')===1?'一局打完，旁边两个人还在争刚才那一波谁先上的。':'打得乱七八糟，三个人倒是笑了半天。';
   say([page('一局结束',result),page('死猪','再来一把？'),page('孙天虎','明天吧，走了。'),page('非力','退了退了，到家吱一声。'),page('网吧门口','推回椅子，出了门，还在说刚才那一波。'),thought(byPov('我和孙天虎往齐东路附近走。下次还是家门口碰。','跟非力一路回去，走没几步又互相骂了两句。下次照旧。','跟他俩分开，各自回家。下次开黑还得叫上他俩。'))],()=>{set('Finished');mark('Stage',5);m.ending=true;});
  }
 }else if(id==='counter')say([page('网管','里面那三台空着。'),page(me,pov===3?'三瓶水。':'再拿三瓶水。')]);
 else if(id==='forward'){
  const flag={Home:'MetStrong',Mall:'GuardJoined',BBQ:'Paid',Sea:'Bench'}[place];
  if(get(flag))go(sceneId+1);
  else say([thought({Home:'先跟'+other+'碰上，再一起走。',Mall:pov===3?(!get('ShiftDone')?'先交完班。':'他俩到了，过去碰个头。'):'死猪还没出来，先等他。',BBQ:get('ExtraEaten')?'还没结账，去找老板。':get('Ate')?'再加点，吃完结账。':'先点串、吃串，吃完再走。',Sea:'先坐会儿，都走到这儿了。'}[place])]);
 }else if(id==='back'){
  if(place==='Mall'&&pov===3&&!get('GuardJoined'))say([thought('先交班，等他俩过来。')]);else go(sceneId-1);
 }
}
const locked=!!m.dialog||m.sitting||m.ending||!!get('NextScene');
for(const n of people)obj(n).activateBehavior('TopDownMovement',n===controlled&&!locked);
local.get('DialogOpen').setNumber(locked?1:0);
const dx=player.getX()-m.last[0],dy=player.getY()-m.last[1];
if(!m.sitting){if(Math.abs(dx)+Math.abs(dy)>.1){m.direction=Math.abs(dx)>Math.abs(dy)?(dx>0?3:2):(dy>0?0:1);player.setAnimation(m.direction);player.playAnimation();}else{player.setAnimation(m.direction);player.pauseAnimation();}}
m.last=[player.getX(),player.getY()];m.prankCooldown=Math.max(0,m.prankCooldown-dt);
if(locked||wasDialog)m.freeTime=0;else{m.freeTime+=dt;const distance=Math.hypot(dx,dy);if(distance<30)m.walked+=distance;}
const aside=(who,body)=>{m.ambient={who,body,time:0};};
const prank=(flag=null,night=false)=>{if(flag)set(flag);set('PrankCount',get('PrankCount')+1);m.ambient=null;m.prank={time:0,actionTime:0,choice:0,responseTime:0,night};m.prankCooldown=10;};
if(!locked){
 if(m.ambient){m.ambient.time+=dt;if(m.ambient.time>3.5)m.ambient=null;}
 if(m.prank){const p=m.prank;p.time+=dt;p.actionTime+=dt;if(!p.choice&&(keys['1']||keys['2'])){p.choice=keys['1']?1:2;p.actionTime=.35;}if(p.choice)p.responseTime+=dt;if(p.responseTime>3.5||p.time>7)m.prank=null;}
 if(keys.q&&get('MetStrong')&&(pov!==3||get('GuardJoined'))&&m.prankCooldown===0){
  if(pov===2&&Math.hypot(obj('Strong').getX()-obj('Player').getX(),obj('Strong').getY()-obj('Player').getY())>120)aside(me,'走近非力再闹。');else prank();
 }
 if(!m.prank&&!m.ambient&&m.freeTime>1){
  if(place==='Home'&&pov===1&&get('MetStrong')&&!get('HomePrank')&&m.walked>95)prank('HomePrank');
  else if(place==='Sea'&&get('Bench')&&!get('SeaPrank')&&player.getX()<670)prank('SeaPrank',true);
  else if(place==='Sea'&&get('Bench')&&player.getX()>720&&!get('GuardLeadRemark')){set('GuardLeadRemark');aside('死猪','走，网吧。');}
  else if(place==='Cafe'&&!get('CafeRemark')&&!get('Finished')){set('CafeRemark');aside('死猪','就这三台。');}
 }
}else if(m.ending||get('NextScene'))clearAside();
const head=m.trail[m.trail.length-1];if(!m.sitting&&Math.hypot(player.getX()-head.x,player.getY()-head.y)>=3){m.trail.push({x:player.getX(),y:player.getY(),direction:m.direction});if(m.trail.length>500)m.trail.shift();}
const trailAt=distance=>{let rem=distance;for(let i=m.trail.length-1;i>0;i--){const a=m.trail[i],b=m.trail[i-1],len=Math.hypot(a.x-b.x,a.y-b.y);if(len>=rem&&len){const f=rem/len;return{x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,direction:a.direction};}rem-=len;}return m.trail[0];};
const moveBuddy=(o,p,speed=240)=>{const x=p.x-o.getX(),y=p.y-o.getY(),dist=Math.hypot(x,y),f=dist?Math.min(1,speed*dt/dist):0;if(dist>.5){o.setPosition(o.getX()+x*f,o.getY()+y*f);o.setAnimation(Math.abs(x)>Math.abs(y)?(x>0?3:2):(y>0?0:1));o.playAnimation();}else{o.setAnimation(p.direction||0);o.pauseAnimation();}return dist;};
const clearFeet=(x,y)=>!scene.getObjects('Solid').some(o=>x+54>o.getX()&&x+18<o.getX()+o.getWidth()&&y+93>o.getY()&&y+78<o.getY()+o.getHeight());
if(pov!==3&&place==='Sea'&&get('Bench')&&player.getX()>720&&player.getY()>320&&obj('Guard').getX()>595)m.guardLead=true;
if(locked||dx<-.5||player.getX()<680||player.getY()<320)m.guardLead=false;
let gap=0;
for(const n of people){
 const o=obj(n);if(follows(n)){gap+=82;if(!locked){
  const f=obj('Player'),target={x:Math.max(8,f.getX()-60),y:f.getY()+3,direction:3};
  if(n==='Strong'&&m.prank&&m.prank.actionTime<1.5&&clearFeet(target.x,target.y)){if(moveBuddy(o,target,330)<18&&m.prank.actionTime>.35){o.setAnimation(5);o.playAnimation();}}
  else if(n==='Guard'&&m.guardLead)moveBuddy(o,{x:Math.min(880,player.getX()+75),y:player.getY(),direction:3});
  else if(n==='Guard'&&place==='Cafe'&&!get('Finished')){if(!m.cafeApproach)m.cafeApproach=1;if(m.cafeApproach===1){if(moveBuddy(o,{x:60,y:390})<5)m.cafeApproach=2;}else moveBuddy(o,{x:600,y:390,direction:1});}
  else moveBuddy(o,trailAt(gap));
 }}
 o.hide(!visible(n));const label=obj('Label'+n);label.hide(!visible(n));text('Label'+n,names[n]+(n===controlled?' · 你':''));
}
if(m.prank&&m.prank.actionTime>.35&&m.prank.actionTime<1.5){if(pov===2&&Math.hypot(dx,dy)<.1){obj('Strong').setAnimation(5);obj('Strong').playAnimation();}if(m.prank.choice===1){obj('Player').setAnimation(5);obj('Player').playAnimation();}}
if(m.sitting)for(const [n,x] of [['Player',360],['Strong',444],['Guard',528]]){obj(n).setPosition(x,282);obj(n).setAnimation(4);obj(n).pauseAnimation();}
for(const n of people){const o=obj(n),label=obj('Label'+n);o.setZOrder(Math.round(o.getY()+93));label.setPosition(Math.round(o.getX()+36-label.getWidth()/2),o.getY()-23);}
if(obj('Stone')){obj('Stone').hide();obj('Ripple').hide();if(m.throwing){const t=m.throwing;t.time+=dt;if(t.time<.9){const f=t.time/.9;obj('Stone').hide(false);obj('Stone').setPosition(t.x+(t.ex-t.x)*f,t.y+(t.ey-t.y)*f-100*Math.sin(Math.PI*f));}else if(t.time<1.9){obj('Ripple').hide(false);obj('Ripple').setPosition(t.ex-36,t.ey-15);obj('Ripple').setOpacity(Math.round(255*(1-(t.time-.9))));}else m.throwing=null;}}
const targets=[],target=(id,label,x,y,r=88,hx=324,hy=606)=>targets.push({id,label,x,y,r,hx,hy});
if(place==='Home'){
 if(!get('MetStrong')){const o=obj(pov===2?'Player':'Strong');target('meet','和'+other+'碰头',o.getX()+36,o.getY()+88);}
 target('home','家附近的路口',150,370,65);target('forward','一起去商场',900,500,80);
}else if(place==='Mall'){
 if(!get('GuardJoined')){if(pov===3){if(!get('ShiftDone'))target('shift','交班',480,350,100);else target('friends','和他们碰头',252,478,95);}else{const o=obj('Guard');target('guard','等死猪下班',o.getX()+36,o.getY()+88,100);}}
 target('notice','看看商场门口',172,365,70);target('forward','去吃羊肉串',900,500,80);target('back','回齐东路附近',45,500,60);
}else if(place==='BBQ'){target('order',get('Paid')?'跟老板打招呼':get('ExtraEaten')?'找老板结账':get('Ate')?'再加点餐':'点肥瘦羊肉串',460,390,92);target('table',get('ExtraOrder')&&!get('ExtraEaten')?'吃加的餐':'吃串，聊两句',160,425,100);target('forward','去海边',905,500);target('back','回商场',45,500,60);
}else if(place==='Sea'){target('sea','吹吹海风',142,275,75,12,198);target('bench','坐一会儿',480,420,120,324,228);target('stones','扔块石头',702,275,78,612,198);target('forward','去网吧开黑',905,500,88,630,465);target('back','回烧烤摊',45,500,60,18,465);
}else{target('pc',get('Finished')?'看看今晚的结尾':get('MatchStep')?'继续这局 LOL':'坐下，三人开黑',405,480,95);target('counter','跟网管打招呼',805,480,80);target('back','回海边走走',48,500,60);}
m.nearest=null;let best=Infinity;for(const t of targets){const d=Math.hypot(player.getX()+36-t.x,player.getY()+88-t.y);if(d<t.r&&d<best){best=d;m.nearest=t;}}
const tasks=place==='Home'?(!get('MetStrong')?'先和'+other+'碰头':'一起去商场接死猪'):
 place==='Mall'?(!get('GuardJoined')?(pov===3?(!get('ShiftDone')?'交完班，再和他们碰头':'他们到了，过去碰个头'):'到门口等死猪下班'):'人齐了，往右去吃串'):
 place==='BBQ'?(!get('Ordered')?'到烤炉前点肥瘦羊肉串':!get('Ate')?'到左边圆桌吃串':!get('ExtraOrder')?'找老板再加点':!get('ExtraEaten')?'加餐好了，回左边圆桌':!get('Paid')?'吃好了，找老板结账':'结完账，往右去海边'):
 place==='Sea'?(!get('Bench')?'在中间长椅坐会儿':m.sitting?'想坐多久就坐多久':'往右去网吧，也能再扔块石头'):
 get('Finished')?'今晚完成了，还可以再走走':get('MatchStep')?'去中间电脑旁，继续这局':'去中间三台电脑，一起开黑';
text('Task',me+'：'+tasks);
const hint=m.sitting&&!m.dialog?{label:'起身走走',hx:324,hy:198}:!locked?m.nearest:null;
obj('HintPlate').hide(!hint);obj('Prompt').hide(!hint);if(hint){obj('HintPlate').setPosition(hint.hx,hint.hy);text('Prompt','E  '+hint.label);obj('Prompt').setPosition(hint.hx+(312-obj('Prompt').getWidth())/2,hint.hy+11);}
const hasAside=!!(m.prank||m.ambient);obj('DialogPlate').hide(!m.dialog);obj('AsidePlate').hide(!!m.dialog||!hasAside);
for(const n of ['Speaker','Dialogue','Choices'])obj(n).hide(!m.dialog&&!hasAside);obj('Help').hide(!!m.dialog||hasAside);
text('Help',m.sitting?'海风吹着，想坐多久就坐多久。 E 起身':'WASD / 方向键 走动   E 互动   Q '+byPov('打闹','闹非力','看他俩闹')+'   J 小记   R 重新选人');
obj('Speaker').setPosition(36,m.dialog?573:609);obj('Dialogue').setPosition(m.dialog?36:132,m.dialog?604:609);obj('Choices').setPosition(36,m.dialog?682:674);
if(m.dialog){const d=m.dialog,p=d.pages[m.page];text('Speaker',p.who);text('Dialogue',wrap(p.text));text('Choices',d.choices&&m.page===d.pages.length-1?d.choices.map((c,i)=>(i+1)+'  '+c.label).join('     '):'E / 空格 / Enter  继续');}
else if(m.prank){
 const p=m.prank;let who='孙天虎',body=p.night?'黑力，人呢？天一黑看不见你了。':'非力，等等你爹。\n孙天虎笑着伸手，拍了一下非力的胳膊。';
 let options=byPov('1  侧身躲开    2  骂回去','1  看他躲，收手    2  笑着骂回去','1  看他俩闹    2  催他们走')+'    可以继续走';
 if(p.choice){options='可以继续走，靠近地点按 E 互动';
  if(pov===1){who='非力';body=p.choice===1?'你他妈手别欠。\n非力侧了侧身，两个人都笑了。':p.night?'你他妈别叭叭，看不见还掐这么准。':'我是你爹！再掐我，我可还手了。';}
  else if(pov===2){who='孙天虎';body=p.choice===1?'行行行，不掐了。\n非力回了一句：“你他妈手别欠。”':'我是你爹，怎么了。\n非力笑着回骂，两个人都没停。';}
  else{who=p.choice===1?'眼前':'死猪';body=p.choice===1?'非力一边躲一边骂，孙天虎手也没闲着。\n你站旁边，看他俩闹。':'走不走。';}
 }text('Speaker',who);text('Dialogue',wrap(body));text('Choices',options);
}else if(m.ambient){text('Speaker',m.ambient.who);text('Dialogue',wrap(m.ambient.body));text('Choices','可以继续走，靠近地点按 E 互动');}
for(const n of ['EndShade','EndTitle','EndSubtitle','EndBody','EndChoices','EndTag'])obj(n).hide(!m.ending);
if(m.ending){
 text('EndTitle','青岛的那些夜晚');text('EndSubtitle','今晚，收工。下次，老地方。');
 text('EndBody',me+'的这一晚\n\n'+byPov('家附近和孙天虎碰头，接上死猪。\n吃串，吹风，开黑。\n最后和孙天虎一路回家。','在家附近等非力，一起去接死猪。\n掐他两下，挨几句骂，一起笑。\n吃完玩完，和非力走回去。','商场交完班，等来那俩人。\n吃串，坐着吹会儿风，打了局游戏。\n各自回家，下次开黑还叫他俩。'));
 text('EndChoices','1  回去自由走走       2  换个视角再来');text('EndTag','MEMORY WORLD  /  V0.8  /  '+me+'视角');
 for(const n of ['EndTitle','EndSubtitle','EndBody','EndChoices','EndTag'])obj(n).setX((960-obj(n).getWidth())/2);
}
