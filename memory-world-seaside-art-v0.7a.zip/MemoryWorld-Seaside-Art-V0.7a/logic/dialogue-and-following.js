// Native GDevelop scene event for the playable seaside art sample.
const scene=runtimeScene,vars=scene.getGame().getVariables(),local=scene.getVariables();
const get=n=>vars.get(n).getAsNumber(),set=(n,v=1)=>vars.get(n).setNumber(v);
const o=n=>scene.getObjects(n)[0],player=o('Player');
const text=(n,s)=>{if(o(n).getString()!==s)o(n).setString(s);};
const wrap=(s,max=42)=>s.split('\n').map(line=>{let out='',width=0;for(const c of line){const w=c.charCodeAt(0)>255?1:.55;if(width+w>max){out+='\n';width=0;}out+=c;width+=w;}return out;}).join('\n');
const down=k=>['1','2'].includes(k)?gdjs.evtTools.input.isKeyPressed(scene,'Num'+k)||gdjs.evtTools.input.isKeyPressed(scene,'Numpad'+k):gdjs.evtTools.input.isKeyPressed(scene,k);
const input=['e','Space','Return','q','r','j','1','2'];
if(!scene._mw){
 scene._mw={keys:{},dialog:null,page:0,sitting:false,prank:null,aside:null,cooldown:0,free:0,trail:[],started:false,nearest:null,throwing:null,direction:0,last:[player.getX(),player.getY()]};
 for(const k of input)scene._mw.keys[k]=down(k);
 for(const s of scene.getObjects('Solid'))s.hide();
 for(let i=0;i<90;i++)scene._mw.trail.push({x:Math.max(0,player.getX()-(89-i)*3),y:player.getY(),direction:0});
}
const m=scene._mw,dt=Math.min(.05,scene.getTimeManager().getElapsedTime()/1000),keys={};
for(const k of input){keys[k]=down(k)&&!m.keys[k];m.keys[k]=down(k);}
const E=keys.e||keys.Space||keys.Return;
const page=(who,body)=>({who,body});
const clear=()=>{m.prank=null;m.aside=null;for(const n of ['Player','Strong','Guard']){o(n).setAnimation(0);o(n).pauseAnimation();}};
const say=(pages,done=null,choices=null)=>{clear();m.dialog={pages,done,choices};m.page=0;};
const close=()=>{const done=m.dialog.done;m.dialog=null;m.free=0;if(done)done();};
const stand=()=>{
 m.sitting=false;m.quiet=false;
 for(const p of m.restore){o(p.name).setPosition(p.x,p.y);o(p.name).setAnimation(0);}
 m.last=[player.getX(),player.getY()];m.free=0;
};
const startPrank=(night=false)=>{m.aside=null;m.prank={time:0,action:0,choice:0,response:0,night};m.cooldown=8;if(night)set('SeaJoke');};
if(keys.r&&!m.dialog&&!m.sitting){
 say([page('重新走一遍？','从海边重新开始，今晚这段小记也会清空。')],null,[{label:'继续逛',run:()=>{}},{label:'重新开始',run:()=>{for(const n of ['Bench','Wind','Stones','SeaJoke','GuardRemark'])set(n,0);set('NextScene',1);}}]);
}else if(m.dialog){
 const d=m.dialog;
 if(d.choices&&m.page===d.pages.length-1){
  const i=keys['1']?0:keys['2']?1:-1;
  if(i>=0){const fn=d.choices[i].run;m.dialog=null;m.free=0;fn();}
 }else if(E){if(m.page<d.pages.length-1)m.page++;else close();}
}else if(m.sitting){if(E)stand();}
else if(keys.j){
 say([page('海边的小记',`吹海风：${get('Wind')?'吹过了':'还没吹'}　坐长椅：${get('Bench')?'坐过了':'还没坐'}\n扔石头：${get('Stones')?'扔过了':'还没扔'}。想再来一遍也行。`)]);
}else if(E&&m.nearest){
 if(m.nearest.id==='bench'){
  m.restore=['Player','Strong','Guard'].map(name=>({name,x:o(name).getX(),y:o(name).getY()}));m.sitting=true;
  say(get('Bench')?[page('孙天虎','再坐会儿呗。'),page('死猪','坐行，别再绕一大圈了。一会儿得开黑。')]:[page('非力','这儿有椅子，坐会儿。'),page('孙天虎','往那边挪挪，大个子别一个人占俩位置。'),page('死猪','总算坐下了。你俩还没走够啊？'),page('非力','歇会儿，吹吹风。'),page('死猪','行，坐够了就去网吧，我都想好第一把玩什么了。')],()=>{set('Bench');set('Wind');m.quiet=true;});
 }else if(m.nearest.id==='wind')say([page('非力','海风吹过来，刚吃完串的那股热乎劲儿慢慢散了。'),page('孙天虎','你往边上站站，风都让你挡住了。'),page('非力','这么大个子，挡个风怎么了。')],()=>set('Wind'));
 else if(m.nearest.id==='stone'){
  const launch=far=>{m.throwing={t:0,x:player.getX()+36,y:player.getY()+42,ex:far?735:690,ey:far?110:170};say([page('非力',far?'石头划了一道弧线，扑通一声落进海里。':'随手一扔，扑通。水花一下就散了。'),page('孙天虎',far?'可以啊，胳膊没白长。':'就为了听这一声？'),page('非力',far?'那是，爹练过。':'对啊，还挺爽。')],()=>set('Stones'));};
  say([page('非力','捡块小石头，往没人的水面扔。')],null,[{label:'用力扔远点',run:()=>launch(true)},{label:'随手扔，听个响',run:()=>launch(false)}]);
 }
}
const locked=!!m.dialog||m.sitting||get('NextScene')!==0;
player.activateBehavior('TopDownMovement',!locked);local.get('DialogOpen').setNumber(locked?1:0);
const dx=player.getX()-m.last[0],dy=player.getY()-m.last[1],moved=Math.hypot(dx,dy);
if(!m.sitting){
 if(moved>.1){m.direction=Math.abs(dx)>Math.abs(dy)?(dx>0?3:2):(dy>0?0:1);player.setAnimation(m.direction);player.playAnimation();m.started=true;}
 else {player.setAnimation(m.direction);player.pauseAnimation();}
 m.last=[player.getX(),player.getY()];
 const head=m.trail[m.trail.length-1];if(Math.hypot(player.getX()-head.x,player.getY()-head.y)>2){m.trail.push({x:player.getX(),y:player.getY(),direction:m.direction});if(m.trail.length>500)m.trail.shift();}
}
m.cooldown=Math.max(0,m.cooldown-dt);
if(locked)m.free=0;else{
 m.free+=dt;
 if(m.aside){m.aside.t+=dt;if(m.aside.t>6)m.aside=null;}
 if(m.prank){const p=m.prank;p.time+=dt;p.action+=dt;if(!p.choice&&(keys['1']||keys['2'])){p.choice=keys['1']?1:2;p.action=.3;}if(p.choice)p.response+=dt;if(p.time>7||p.response>3.4)m.prank=null;}
 if(keys.q&&m.cooldown===0)startPrank();
 if(!m.prank&&!m.aside&&m.free>1){
  if(get('Bench')&&!get('SeaJoke'))startPrank(true);
  else if(!get('GuardRemark')&&m.started&&m.free>2.5){set('GuardRemark');m.aside={t:0,who:'死猪',body:'还走啊？找个椅子坐坐，坐完去网吧。'};}
 }
}
const trailAt=distance=>{let rem=distance;for(let i=m.trail.length-1;i>0;i--){const a=m.trail[i],b=m.trail[i-1],len=Math.hypot(a.x-b.x,a.y-b.y);if(len>=rem&&len){const f=rem/len;return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,direction:a.direction};}rem-=len;}return m.trail[0];};
const clearFeet=(x,y)=>!scene.getObjects('Solid').some(s=>x+54>s.getX()&&x+18<s.getX()+s.getWidth()&&y+93>s.getY()&&y+78<s.getY()+s.getHeight());
const move=(who,p,speed=230)=>{const s=o(who),dx=p.x-s.getX(),dy=p.y-s.getY(),dist=Math.hypot(dx,dy);if(dist>.6){const f=Math.min(1,speed*dt/dist);s.setPosition(s.getX()+dx*f,s.getY()+dy*f);s.setAnimation(Math.abs(dx)>Math.abs(dy)?(dx>0?3:2):(dy>0?0:1));s.playAnimation();}else{s.setAnimation(p.direction||0);s.pauseAnimation();}return dist;};
if(!locked){
 for(const [who,gap] of [['Strong',82],['Guard',164]]){
  const target={x:Math.max(0,player.getX()-60),y:player.getY()+3,direction:3};
  if(who==='Strong'&&m.prank&&m.prank.action<1.5&&clearFeet(target.x,target.y)){
   if(move(who,target,330)<18&&m.prank.action>.3){o(who).setAnimation(5);o(who).playAnimation();}
  }else if(who==='Guard'&&get('Bench')&&player.getX()>720&&dy>=-.1&&dx>=-.1&&o(who).getX()>610){move(who,{x:Math.min(880,player.getX()+75),y:player.getY(),direction:3},240);}
  else if(m.started)move(who,trailAt(gap));
  else {o(who).setAnimation(0);o(who).pauseAnimation();}
 }
 if(m.prank?.choice===1&&m.prank.action<1.5){player.setAnimation(5);player.playAnimation();}
}
if(m.sitting){for(const [name,x] of [['Player',360],['Strong',444],['Guard',528]]){o(name).setPosition(x,282);o(name).setAnimation(4);o(name).pauseAnimation();}}
for(const name of ['Player','Strong','Guard']){
 const s=o(name),label=o('Label'+name);s.setZOrder(Math.round(s.getY()+93));label.setPosition(Math.round(s.getX()+36-label.getWidth()/2),s.getY()-23);
}
o('Stone').hide();o('Ripple').hide();
if(m.throwing){const p=m.throwing;p.t+=dt;if(p.t<.9){const f=p.t/.9;o('Stone').hide(false);o('Stone').setPosition(p.x+(p.ex-p.x)*f,p.y+(p.ey-p.y)*f-95*Math.sin(f*Math.PI));}else if(p.t<2){o('Ripple').hide(false);o('Ripple').setPosition(p.ex-36,p.ey-15);o('Ripple').setOpacity(Math.round(255*(2-p.t)/1.1));}else m.throwing=null;}
const targets=[{id:'bench',label:'E  坐一会儿',x:480,y:420,r:120,hx:324,hy:228},{id:'wind',label:'E  吹吹海风',x:142,y:275,r:75,hx:12,hy:198},{id:'stone',label:'E  扔块石头',x:702,y:275,r:78,hx:612,hy:198}];
m.nearest=null;let best=Infinity;
for(const t of targets){const dist=Math.hypot(player.getX()+36-t.x,player.getY()+88-t.y);if(dist<t.r&&dist<best){best=dist;m.nearest=t;}}
const hint=m.sitting&&!m.dialog?{label:'E  起身走走',hx:324,hy:198}:!locked?m.nearest:null;
o('HintPlate').hide(!hint);o('Prompt').hide(!hint);
if(hint){o('HintPlate').setPosition(hint.hx,hint.hy);text('Prompt',hint.label);o('Prompt').setPosition(hint.hx+(312-o('Prompt').getWidth())/2,hint.hy+11);}
const hasAside=!!(m.prank||m.aside);
o('DialogPlate').hide(!m.dialog);o('AsidePlate').hide(!!m.dialog||!hasAside);
for(const name of ['Speaker','Dialogue','Choices'])o(name).hide(!m.dialog&&!hasAside);
o('Help').hide(!!m.dialog||hasAside);
text('Help',m.sitting?'海风吹着，想坐多久就坐多久。  E 起身':'WASD / 方向键 走动    E 互动    Q 打闹    J 小记    R 重来');
if(m.dialog){
 const d=m.dialog,p=d.pages[m.page];text('Speaker',p.who);text('Dialogue',wrap(p.body));
 text('Choices',d.choices&&m.page===d.pages.length-1?d.choices.map((c,i)=>(i+1)+'  '+c.label).join('       '):'E / 空格 / Enter  继续');
 o('Speaker').setPosition(36,573);o('Dialogue').setPosition(36,604);o('Choices').setPosition(36,682);
}else if(hasAside){
 let who='',body='',choices='可以继续走；靠近地点按 E 互动';
 if(m.prank){const p=m.prank;who=p.choice?'非力':'孙天虎';body=p.choice===1?'又来！看得挺准啊。非力侧了侧身，笑着躲开他的手。':p.choice===2?'我是你爹！再掐我，我可还手了啊。':p.night?'天都黑了，非力人呢？我怎么快看不见你了。':'孙天虎凑过来，笑着掐了一下你的胳膊：“等等你爹。”';if(!p.choice)choices='1  侧身躲一下       2  回嘴       也可以继续走';}
 else {who=m.aside.who;body=m.aside.body;}
 text('Speaker',who);text('Dialogue',wrap(body,44));text('Choices',choices);
 o('Speaker').setPosition(36,609);o('Dialogue').setPosition(118,609);o('Choices').setPosition(36,674);
}
